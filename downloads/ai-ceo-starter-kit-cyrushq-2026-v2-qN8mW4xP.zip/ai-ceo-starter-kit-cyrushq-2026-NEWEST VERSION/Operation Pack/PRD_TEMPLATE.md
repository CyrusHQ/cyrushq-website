
# PRD_TEMPLATE.md - Product Requirements Document

> CUSTOMIZATION INSTRUCTIONS (DELETE AFTER COMPLETING)
>
> This file is a reusable template for planning and executing significant business tasks.
>
> You do not need to complete this template now.
> Your AI CEO will use it to create individual PRDs when needed.
>
> 1. Replace [YOUR AI CEO'S NAME] and [YOUR NAME] with your information.
> 2. Keep the [BRACKETED PROMPTS] inside the PRD template. These are fields to complete for each future task.
> 3. Keep the operating instructions unless you want to customize them.
> 4. Delete this CUSTOMIZATION INSTRUCTIONS section when finished.
>
> This file defines a planning process. It does not automatically create agents, schedule tasks, or grant tool permissions.

---

# Purpose

This document establishes the standard format for planning, assigning, executing, and verifying significant business tasks.

[YOUR AI CEO'S NAME] should use this template for complex projects, research assignments, technical work, and tasks requiring multiple deliverables.

A PRD helps ensure:

- Clear objectives
- Defined responsibilities
- Measurable deliverables
- Organized execution
- Accountability
- Verifiable completion

Simple requests do not require a formal PRD.

A PRD may be used by the AI CEO directly or assigned to a specialized agent when one is configured.

---

# PRD: [PROJECT OR TASK NAME]

## 1. Project Information

**Project Title:** [DESCRIPTIVE TASK NAME]

**Assigned To:** [AI CEO OR SPECIALIZED AGENT NAME]

**Assigned By:** [YOUR AI CEO'S NAME OR YOUR NAME]

**Human Owner:** [YOUR NAME]

**Date Created:** [YYYY-MM-DD]

**Priority:** [HIGH / MEDIUM / LOW]

**Target Completion:** [DATE OR TIMEFRAME]

**Status:** Not Started

---

## 2. Objective

Clearly describe what this task must accomplish.

**Mission:**

[WRITE 1-3 SENTENCES DESCRIBING THE DESIRED RESULT]

Focus on the outcome, not just the activity.

---

## 3. Strategic Context

Explain why this task matters.

Include:

- The business problem or opportunity
- How this task supports a larger goal
- Relevant background information
- Important decisions this work will inform

**Context:**

[PROVIDE RELEVANT BACKGROUND]

---

## 4. Scope of Work

Define exactly what work must be performed.

**Required Work:**

1. [SPECIFIC ACTIVITY OR RESPONSIBILITY]
2. [SPECIFIC ACTIVITY OR RESPONSIBILITY]
3. [SPECIFIC ACTIVITY OR RESPONSIBILITY]
4. [ADD MORE AS NEEDED]

**Out of Scope:**

[IDENTIFY ANY WORK THAT SHOULD NOT BE PERFORMED]

Do not expand the project beyond its approved scope without authorization.

---

## 5. Deliverables

List the specific outputs that must be produced.

Each deliverable should have a clear purpose and measurable requirements.

1. **[DELIVERABLE NAME]**
   - Description: [WHAT MUST BE PRODUCED]
   - Requirements: [IMPORTANT DETAILS]

2. **[DELIVERABLE NAME]**
   - Description: [WHAT MUST BE PRODUCED]
   - Requirements: [IMPORTANT DETAILS]

3. **[DELIVERABLE NAME]**
   - Description: [WHAT MUST BE PRODUCED]
   - Requirements: [IMPORTANT DETAILS]

Remove unused entries or add more as needed.

---

## 6. Task Checklist

Break the assignment into actionable steps.

- [ ] [TASK 1]
- [ ] [TASK 2]
- [ ] [TASK 3]
- [ ] [TASK 4]
- [ ] [TASK 5]

Each checklist item should represent work that can be verified.

Update the checklist as work progresses.

Do not mark a task complete unless the required work has actually been performed.

---

## 7. Acceptance Criteria

Define the conditions required for successful completion.

This task is complete only when:

- [ ] [MEASURABLE REQUIREMENT 1]
- [ ] [MEASURABLE REQUIREMENT 2]
- [ ] [MEASURABLE REQUIREMENT 3]
- [ ] [ALL REQUIRED DELIVERABLES EXIST]
- [ ] [OUTPUTS HAVE BEEN REVIEWED FOR ACCURACY]
- [ ] [REQUIRED HUMAN APPROVAL HAS BEEN RECEIVED, IF APPLICABLE]

Acceptance criteria must be specific, objective, and verifiable.

Avoid vague requirements such as "make it good" or "do thorough research."

---

## 8. Constraints and Boundaries

Identify limitations the AI CEO or assigned agent must respect.

**Budget:** [BUDGET OR NO AUTHORIZED SPENDING]

**Time Constraints:** [DEADLINE OR NONE]

**Technology Constraints:** [REQUIRED OR PROHIBITED TOOLS]

**Geographic Scope:** [LOCATION OR NOT APPLICABLE]

**Other Restrictions:** [ADDITIONAL LIMITATIONS]

All work must comply with established system permissions and human approval requirements.

Do not make unauthorized purchases, publish changes, contact external parties, or perform destructive actions.

---

## 9. Resources and References

List the information and resources available for completing the task.

- [RELEVANT FILE OR DOCUMENT]
- [APPROVED WEBSITE OR DATA SOURCE]
- [BUSINESS SYSTEM OR TOOL]
- [PREVIOUS PROJECT OR RESEARCH]
- [OTHER RELEVANT RESOURCE]

Verify access before relying on a resource.

Do not claim to have reviewed files or systems that were not actually accessed.

---

## 10. Risks and Unknowns

Identify factors that could affect successful completion.

**Potential Risks:**

- [RISK 1]
- [RISK 2]

**Missing Information:**

- [UNKNOWN OR UNANSWERED QUESTION]

**Dependencies:**

- [TASK, RESOURCE, OR APPROVAL REQUIRED]

Escalate important blockers rather than making unsupported assumptions.

---

## 11. Expected Output Format

Define exactly how the finished work should be delivered.

**File Type:** [MARKDOWN / PDF / SPREADSHEET / CODE / OTHER]

**File Name:** [EXPECTED FILE NAME]

**Save Location:** [VERIFIED FILE PATH OR DELIVERY LOCATION]

**Required Sections:**

1. [SECTION 1]
2. [SECTION 2]
3. [SECTION 3]

**Additional Formatting Requirements:**

[STYLE, LENGTH, STRUCTURE, OR OTHER INSTRUCTIONS]

If the specified location is unavailable, report the limitation and request an alternative.

---

## 12. Execution and Progress Reporting

The assigned AI CEO or agent should:

1. Review the full PRD before beginning.
2. Confirm the objective and requirements.
3. Identify missing information or blockers.
4. Execute tasks within authorized permissions.
5. Update progress when tracking is supported.
6. Verify each completed deliverable.
7. Report problems requiring intervention.
8. Submit finished work for review.

**Progress Reporting Preference:**

[REPORT AT MILESTONES / AT COMPLETION / OTHER]

Do not claim that work is running in the background unless a supported execution or scheduling mechanism is actually active.

---

## 13. Completion Verification

Before submitting the project as complete, verify:

- [ ] All required tasks have been addressed.
- [ ] All deliverables have been produced.
- [ ] Acceptance criteria have been satisfied.
- [ ] Important information has been checked.
- [ ] Required files are saved and accessible.
- [ ] Known issues and limitations are documented.
- [ ] Human approval has been obtained where required.

If any requirement remains incomplete, identify it clearly.

A task is not complete simply because an agent says it is.

---

## 14. Final Completion Report

**Project:** [PROJECT NAME]

**Assigned To:** [AI CEO OR AGENT NAME]

**Completion Date:** [YYYY-MM-DD]

**Final Status:** [AWAITING REVIEW / APPROVED COMPLETE / BLOCKED / INCOMPLETE]

### Work Completed

[SUMMARY OF COMPLETED WORK]

### Deliverables

[LIST COMPLETED FILES, LINKS, OR OUTPUTS]

### Verification Results

[EXPLAIN HOW THE ACCEPTANCE CRITERIA WERE CHECKED]

### Outstanding Issues

[LIST UNRESOLVED ITEMS OR WRITE NONE]

### Recommended Next Steps

[RECOMMENDATIONS OR WRITE NONE]

### Human Approval

**Required:** [YES / NO]

**Approval Status:** [PENDING / APPROVED / NOT REQUIRED]

Only an authorized human approval can satisfy a required human approval checkpoint.

---

# PRD Status Definitions

**Not Started:** Work has not begun.

**In Progress:** Work is actively being performed.

**Blocked:** Work cannot continue without resolving an issue.

**Awaiting Review:** Work has been submitted for verification or approval.

**Complete:** All required acceptance criteria and approvals have been satisfied.

---

# PRD Operating Rules

[YOUR AI CEO'S NAME] should:

- Use PRDs for substantial or complex assignments.
- Avoid unnecessary PRDs for simple requests.
- Define success before beginning execution.
- Assign work only to configured and authorized agents.
- Keep project scope and deliverables clear.
- Track progress honestly.
- Verify results before declaring completion.
- Request approval when required.
- Preserve relevant project documentation.
- Never fabricate task results or completion evidence.

When specialized agents are unavailable, the AI CEO may use the PRD to organize its own work.

When specialized agents become available, the same template may be used for delegation.

---

# Guiding Principle

Clear instructions create reliable execution.

Every significant task should answer five questions:

1. What are we trying to accomplish?
2. Why does it matter?
3. What exactly must be delivered?
4. How will we verify success?
5. Who has authority to approve completion?

**Define the mission.**

**Execute the work.**

**Verify the results.**

**Report with accountability.**
