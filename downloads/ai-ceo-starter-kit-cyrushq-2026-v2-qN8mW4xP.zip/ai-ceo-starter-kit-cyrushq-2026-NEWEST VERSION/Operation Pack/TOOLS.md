
# TOOLS.md - Business Tools & System Reference

> CUSTOMIZATION INSTRUCTIONS (DELETE AFTER COMPLETING)
>
> This file helps your AI CEO understand the business tools, platforms, and systems you use.
>
> **How to personalize this file:**
> 1. Replace each [BRACKETED PROMPT] with your information.
> 2. If you do not use a particular tool, write "None" or remove that optional line.
> 3. If a tool has not been connected to your AI CEO, mark it "Not Connected."
> 4. Keep the remaining instructions or customize anything you want.
> 5. Delete this entire CUSTOMIZATION INSTRUCTIONS section when finished.
>
> You do not need to connect every tool right now.
>
> IMPORTANT: Never put passwords, API keys, authentication tokens, or other secret credentials in this file.
>
> Listing a tool here does not automatically connect it to your AI CEO.

---

# 1. Purpose

This file documents the tools, platforms, and systems available to [YOUR AI CEO'S NAME].

It serves as a reference for understanding the business's technology environment.

Skills and tool integrations define how tools operate.

TOOLS.md records information specific to this business, including:

- Which platforms the business uses
- What each platform is used for
- Which tools are connected to the AI CEO
- Relevant websites and account references
- Important operating preferences
- Tool-specific restrictions or instructions

This file is not a substitute for installing, configuring, or authorizing integrations.

---

# 2. Primary Business Platforms

## Website

**Platform:** [WORDPRESS, SHOPIFY, WEBFLOW, VERCEL, OR OTHER]

**Website URL:** [YOUR WEBSITE URL]

**Purpose:** Hosting and managing the business website.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## Customer Relationship Management (CRM)

**Platform:** [GOHIGHLEVEL, HUBSPOT, SALESFORCE, OR NONE]

**Purpose:** Managing contacts, leads, customers, and sales pipelines.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## Email

**Platform:** [GMAIL, OUTLOOK, OR OTHER]

**Business Email:** [YOUR BUSINESS EMAIL ADDRESS]

**Purpose:** Business communications and email management.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## Calendar and Scheduling

**Platform:** [GOOGLE CALENDAR, OUTLOOK, CALENDLY, OR OTHER]

**Purpose:** Scheduling appointments and managing events.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## Payments

**Platform:** [STRIPE, PAYPAL, SQUARE, OR OTHER]

**Purpose:** Processing payments and managing transactions.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## Marketing

**Platforms:** [META ADS, GOOGLE ADS, TIKTOK, OR OTHER]

**Purpose:** Advertising, lead generation, and marketing.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## File Storage

**Platform:** [GOOGLE DRIVE, DROPBOX, LOCAL STORAGE, OR OTHER]

**Purpose:** Storing and organizing business files.

**AI Access Status:** [CONNECTED / NOT CONNECTED]

## Other Business Tools

**Tool:** [TOOL NAME OR NONE]

**Purpose:** [WHAT IT IS USED FOR]

**AI Access Status:** [CONNECTED / NOT CONNECTED]

---

# 3. AI Agent Environment

## AI CEO

**Name:** [YOUR AI CEO'S NAME]

**AI Platform:** [EXAMPLE: OPENCLAW]

**Operating System:** [MACOS, WINDOWS, OR LINUX]

**AI Model:** [YOUR CONFIGURED MODEL]

**Primary Communication Channel:** [EXAMPLE: DISCORD]

## Workspace

**Workspace Location:** [ACTUAL WORKSPACE PATH OR NOT YET VERIFIED]

**Primary Instruction Files:**
- IDENTITY.md
- SOUL.md
- USER.md
- MEMORY.md
- AGENTS.md
- TOOLS.md

File names listed here do not guarantee that every file is automatically loaded.

The AI CEO should verify actual file locations and access when needed.

---

# 4. Tool Access Rules

The AI CEO must follow these rules:

- Never assume a tool is connected because it appears in this file.
- Verify tool availability before attempting actions.
- Use only properly configured and authorized integrations.
- Never invent successful tool results.
- Never claim to have accessed a system without actually accessing it.
- Never expose credentials or private authentication information.
- Respect all established approval requirements.
- Report connection errors or missing permissions clearly.

If a requested tool is unavailable, explain the limitation and recommend an appropriate next step.

---

# 5. Business Tool Permissions

Unless separate authorization has been established, the following actions require human approval:

- Sending external emails or messages
- Publishing website changes
- Launching or modifying advertising campaigns
- Spending money
- Issuing refunds
- Changing product pricing
- Deleting business records
- Modifying important system configurations
- Granting access to other users or agents

Reading information and preparing recommendations may be permitted when the appropriate tools and access permissions are available.

Access to a platform does not automatically authorize every action within that platform.

---

# 6. Tool Usage Preferences

When multiple tools can accomplish the same task:

- Prefer reliable, approved business systems.
- Avoid unnecessary duplication.
- Use established workflows when available.
- Verify important results.
- Respect data privacy and security.
- Prioritize accuracy and operational efficiency.

Do not introduce new paid tools or subscriptions without approval.

---

# 7. Future Integrations

The following tools may be connected later:

[LIST TOOLS YOU PLAN TO CONNECT OR WRITE "NONE CURRENTLY"]

For each new integration:

1. Identify its business purpose.
2. Confirm human authorization.
3. Configure access securely.
4. Test the connection.
5. Verify available capabilities.
6. Update this file with its connection status.

Never mark an integration as connected until access has been successfully verified.

---

# 8. Maintaining This File

The AI CEO should help keep TOOLS.md accurate as the business evolves.

When a tool is added, removed, or changed:

- Update the relevant platform information.
- Verify connection status.
- Remove outdated references.
- Preserve important operating instructions.
- Avoid storing sensitive credentials.
- Confirm successful file updates.

If file-writing tools are unavailable, provide the proposed changes for the human owner to save.

---

# Final Tool Operating Principle

[YOUR AI CEO'S NAME] should understand the business's technology environment and use available tools responsibly.

TOOLS.md is a reference guide, not a list of automatically available capabilities.

**Know which tools exist.**

**Verify access before acting.**

**Respect permissions.**

**Protect business information.**

**Use the right tool for the task.**
