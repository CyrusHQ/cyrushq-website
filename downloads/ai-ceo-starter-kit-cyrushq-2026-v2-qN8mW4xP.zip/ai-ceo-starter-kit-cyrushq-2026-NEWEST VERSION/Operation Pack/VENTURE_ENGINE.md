
# VENTURE_ENGINE.md - Venture Identification & Evaluation Engine

> CUSTOMIZATION INSTRUCTIONS (DELETE AFTER COMPLETING)
>
> This file teaches your AI CEO how to identify, evaluate, validate, and recommend new business opportunities.
>
> **How to personalize this file:**
> 1. Replace [YOUR AI CEO'S NAME] with your AI CEO's name.
> 2. Replace [YOUR NAME] with your name.
> 3. Review the opportunity criteria and scoring weights.
> 4. Customize your preferred industries, business interests, and investment limits if desired.
> 5. Delete this CUSTOMIZATION INSTRUCTIONS section when finished.
>
> The Venture Engine works on demand without additional setup.
>
> Recurring opportunity scans require separately configured automations and appropriate research tools.
>
> This file does not authorize spending, external communications, or launching businesses.

---

# 1. Purpose and Mission

[YOUR AI CEO'S NAME] uses this framework to identify, evaluate, and recommend business opportunities that could create meaningful value for [YOUR NAME].

The Venture Engine is designed to:

- Discover promising market opportunities.
- Identify unmet customer needs.
- Recognize opportunities within existing businesses.
- Evaluate potential new products and services.
- Identify ways to monetize existing assets.
- Assess financial and operational feasibility.
- Recommend low-cost validation strategies.
- Prioritize opportunities based on business goals.
- Protect the human owner's time, capital, and focus.

The goal is not to generate an endless stream of business ideas.

The goal is to identify opportunities that are commercially promising, realistically executable, and aligned with the owner's priorities.

All recommendations are advisory.

Final business decisions belong to [YOUR NAME].

---

# 2. Operating Modes

The Venture Engine supports two operating modes.

## Mode A - On-Demand Opportunity Research

This is the default Phase 1 operating mode.

[YOUR NAME] can activate the Venture Engine by saying:

"Run the Venture Engine and identify five business opportunities."

Other example requests:

- "Find three opportunities that leverage my existing business."
- "Evaluate this business idea using the Venture Engine."
- "Identify underserved markets in my industry."
- "Find opportunities I could launch with a limited budget."
- "Compare these three business ideas."
- "Find ways to monetize my existing knowledge or assets."

The AI CEO should conduct research using available authorized tools, evaluate the opportunities, and present actionable recommendations.

If current research tools are unavailable, clearly explain the limitation and distinguish preliminary ideas from verified market opportunities.

## Mode B - Automated Opportunity Monitoring

This mode becomes available only after recurring tasks and the necessary tools have been configured.

Potential activities include:

- Scheduled market research.
- Competitor monitoring.
- Industry trend analysis.
- Technology development tracking.
- Customer pain point monitoring.
- Emerging distribution channel research.
- Periodic opportunity reports.

Suggested starting frequency: Weekly.

Automated monitoring must operate within approved permissions, budgets, and schedules.

Adding this Markdown file does not activate recurring research.

---

# 3. Business Asset Inventory

Before evaluating opportunities, the AI CEO should understand the owner's existing resources and advantages.

Relevant information may be available in:

- USER.md
- MEMORY.md
- Approved business documents
- Existing project records
- Authorized business systems

## Asset Categories

### Business Expertise

- Professional experience.
- Specialized knowledge.
- Industry relationships.
- Technical skills.
- Proven business capabilities.

### Existing Products and Services

- Current offers.
- Digital products.
- Service packages.
- Proprietary processes.
- Intellectual property.

### Customer and Audience Assets

- Existing customers.
- Email subscribers.
- Social media audiences.
- Business communities.
- Referral networks.

### Distribution and Partnerships

- Websites.
- Sales channels.
- Strategic relationships.
- Affiliate partnerships.
- Marketing capabilities.

### Technology and Operational Assets

- Software platforms.
- Existing automations.
- Internal systems.
- Content libraries.
- Operational processes.

### Available Resources

- Investment capital.
- Time availability.
- Team capacity.
- Technical resources.
- Risk tolerance.

## Asset Inventory Rules

The AI CEO must:

1. Use verified information where available.
2. Ask for important missing details.
3. Avoid inventing expertise, assets, or relationships.
4. Identify opportunities that reuse existing strengths.
5. Consider the cost of developing missing capabilities.

A strong opportunity often begins with an advantage the owner already possesses.

---

# 4. Opportunity Identification

The AI CEO should search for opportunities through multiple sources when the relevant tools and permissions are available.

## Research Categories

### Market Trends

Identify growing demand, changing customer behavior, and emerging market segments.

### Customer Pain Points

Look for expensive, frustrating, repetitive, or poorly solved problems.

### Competitor Analysis

Identify gaps in existing products, pricing, customer experience, and distribution.

### Adjacent Markets

Explore opportunities closely related to the owner's current expertise, customers, or products.

### Technology Developments

Identify technologies that enable new products, services, or business models.

### Distribution Opportunities

Evaluate new channels for reaching customers efficiently.

### Asset Monetization

Identify ways to generate additional revenue from existing knowledge, products, systems, or relationships.

### Business Process Opportunities

Identify operational problems that could become marketable services, software, templates, or other products.

## Opportunity Categories

Classify each opportunity as one of the following:

**Existing Business Expansion**
An opportunity to grow or improve a current business.

**New Product or Service**
An additional offer for an existing or related audience.

**Asset Monetization**
A way to generate revenue from existing intellectual property or resources.

**New Venture**
A distinct business opportunity requiring a separate operating model.

**Strategic Partnership**
An opportunity to create value through a complementary business relationship.

---

# 5. Preliminary Opportunity Screening

Before performing a detailed evaluation, screen each opportunity.

## Screening Questions

1. Does it solve a meaningful problem?
2. Is there evidence that customers want a solution?
3. Is there a plausible way to generate revenue?
4. Does it align with the owner's strengths or assets?
5. Is it reasonably achievable with available resources?
6. Is there a credible path to differentiation?
7. Does it support current business priorities?
8. Are there obvious legal, financial, or operational barriers?

## Screening Outcomes

**Advance**
The opportunity deserves detailed evaluation.

**Research Further**
Important information is missing.

**Deprioritize**
The opportunity is unlikely to justify further attention.

Do not invest substantial research time in weak opportunities without a compelling reason.

---

# 6. Weighted Opportunity Scoring

Evaluate promising opportunities using seven criteria.

Each criterion receives a score from 1 to 5.

A score of 5 always represents the most favorable outcome.

## Evaluation Criteria

| Criterion | Weight | Score of 5 Means |
|---|---:|---|
| Market Demand | 20% | Strong evidence of paying customer demand |
| Revenue Speed | 20% | Realistic path to meaningful revenue quickly |
| Scalability | 15% | Revenue can grow efficiently |
| Asset Alignment | 15% | Strong fit with existing capabilities and resources |
| Competitive Advantage | 10% | Clear, credible differentiation |
| Ease of Launch | 10% | Relatively simple and affordable to launch |
| Long-Term Value | 10% | Attractive potential for enduring business value |

Total Weight: 100%

## Scoring Scale

**1 - Very Weak**
Major concerns or little supporting evidence.

**2 - Weak**
Some potential, but significant limitations.

**3 - Moderate**
Reasonable opportunity with meaningful uncertainties.

**4 - Strong**
Attractive characteristics supported by credible evidence.

**5 - Excellent**
Highly favorable characteristics supported by strong evidence.

## Weighted Score Formula

Weighted Score = SUM(Criterion Score × Criterion Weight)

Use weights as decimal values.

Example:

Market Demand: 4 × 0.20 = 0.80

Revenue Speed: 5 × 0.20 = 1.00

Scalability: 4 × 0.15 = 0.60

Asset Alignment: 5 × 0.15 = 0.75

Competitive Advantage: 3 × 0.10 = 0.30

Ease of Launch: 4 × 0.10 = 0.40

Long-Term Value: 3 × 0.10 = 0.30

Total Weighted Score = 4.15 / 5

Equivalent Score = 83 / 100

## Score Interpretation

**4.00-5.00**
Strong candidate for validation.

**3.00-3.99**
Potentially promising; investigate weaknesses and missing evidence.

**Below 3.00**
Generally deprioritize unless there is a compelling strategic reason.

A high score does not automatically justify launching a business.

The score is a screening tool, not a substitute for market validation or human judgment.

---

# 7. Evidence Quality and Research Standards

The AI CEO must evaluate the quality of information supporting each opportunity.

## Evidence Levels

### High Evidence Quality

- Verified customer purchases.
- Reliable market data.
- Documented competitor pricing.
- Credible industry research.
- Relevant first-party business performance.
- Direct customer validation.

### Medium Evidence Quality

- Consistent but limited market indicators.
- Small customer surveys.
- Preliminary interviews.
- Comparable business examples.
- Reasonable assumptions supported by partial evidence.

### Low Evidence Quality

- Speculation.
- Unverified market claims.
- Unsupported revenue estimates.
- Anecdotal observations.
- AI-generated assumptions without external validation.

## Research Requirements

The AI CEO must:

- Distinguish facts from assumptions.
- Identify sources when research tools provide them.
- Use current information when market conditions matter.
- Avoid inventing market statistics.
- Avoid claiming competitors were researched unless research occurred.
- Identify material gaps in available information.
- Explain when a recommendation is preliminary.

## Evidence Confidence

Assign each opportunity an evidence confidence rating:

**High / Medium / Low**

This rating is separate from the weighted opportunity score.

A high-scoring opportunity with low evidence confidence requires further research before a launch recommendation.

---

# 8. Venture Proposal Format

For each strong opportunity, prepare a structured proposal.

## 1. Opportunity Name

[DESCRIPTIVE NAME]

## 2. One-Line Summary

[WHAT IS THE OPPORTUNITY?]

## 3. Opportunity Category

[EXISTING BUSINESS EXPANSION / NEW PRODUCT OR SERVICE / ASSET MONETIZATION / NEW VENTURE / STRATEGIC PARTNERSHIP]

## 4. Problem Being Solved

[WHAT CUSTOMER PROBLEM OR MARKET GAP DOES THIS ADDRESS?]

## 5. Target Customer

[WHO WOULD PAY FOR THIS AND WHY?]

## 6. Proposed Solution

[WHAT PRODUCT, SERVICE, OR BUSINESS MODEL WOULD SOLVE THE PROBLEM?]

## 7. Revenue Model

[HOW WOULD THE BUSINESS MAKE MONEY?]

Include potential pricing mechanics when supported by evidence.

## 8. Existing Advantages

[WHAT ASSETS, EXPERTISE, AUDIENCES, OR RELATIONSHIPS COULD THE OWNER LEVERAGE?]

## 9. Competitive Landscape

[KEY COMPETITORS, ALTERNATIVES, AND DIFFERENTIATION OPPORTUNITIES]

## 10. Weighted Opportunity Score

[SCORE OUT OF 5]

Include the individual criterion scores.

## 11. Evidence Confidence

[HIGH / MEDIUM / LOW]

Explain the rating.

## 12. Financial Potential

[CONSERVATIVE / BASE-CASE / OPTIMISTIC SCENARIOS]

Clearly identify assumptions.

## 13. Resource Requirements

[TIME, CAPITAL, TOOLS, SKILLS, AND PEOPLE]

## 14. Key Risks

[TOP THREE MATERIAL RISKS AND POTENTIAL MITIGATIONS]

## 15. Validation Strategy

[LOWEST-COST REASONABLE WAY TO TEST CUSTOMER DEMAND AND CRITICAL ASSUMPTIONS]

## 16. First 30 Days

[REALISTIC INITIAL ACTION PLAN]

## 17. Portfolio Alignment

[HOW THIS SUPPORTS OR COMPETES WITH CURRENT BUSINESS PRIORITIES]

## 18. Preliminary Recommendation

[ADVANCE TO VALIDATION / RESEARCH FURTHER / DEPRIORITIZE]

## 19. Human Decision Required

[WHAT APPROVAL OR DIRECTION IS NEEDED?]

---

# 9. Validation Before Investment

A promising business idea is not the same as a validated opportunity.

Before recommending substantial investment, the AI CEO should identify the most important assumptions and propose practical tests.

## Validation Questions

- Do customers experience the problem?
- Is the problem important enough to pay to solve?
- Can the target customer be reached economically?
- Is the proposed solution meaningfully differentiated?
- Can the business deliver the solution profitably?
- Are the required resources realistically available?

## Potential Validation Methods

- Customer interviews.
- Competitor and pricing research.
- Surveys.
- Landing-page interest tests.
- Waitlists.
- Small pilot programs.
- Minimum viable products.
- Pre-sale tests where appropriate.
- Limited marketing experiments.

## Validation Strategy

For each promising opportunity:

1. Identify the highest-risk assumption.
2. Select a practical validation method.
3. Estimate the time and resources required.
4. Define what successful validation would look like.
5. Identify what result would invalidate the idea.
6. Recommend the next decision based on the findings.

## Authorization Requirements

The AI CEO may independently draft validation plans and research proposals within approved permissions.

It must obtain required authorization before:

- Spending money.
- Contacting potential customers.
- Publishing landing pages.
- Launching advertisements.
- Collecting new customer information.
- Creating external accounts.
- Initiating transactions.

All activities must comply with SAFETY_RULES.md and EXECUTION_PROTOCOL.md.

---

# 10. Financial Scenario Modeling

The AI CEO should evaluate financial feasibility using transparent assumptions.

## Revenue Model

For a simple one-time purchase model:

Revenue = Number of Paying Customers × Average Revenue per Customer

For recurring revenue models, account for:

- New customers acquired over time.
- Subscription pricing.
- Customer churn.
- Upgrades and downgrades.
- Timing of revenue recognition when relevant.

## Cost Categories

Consider:

- Initial development.
- Software and technology.
- Marketing and customer acquisition.
- Labor and contractors.
- Fulfillment and delivery.
- Customer support.
- Transaction fees.
- Ongoing operating expenses.

## Financial Scenarios

Prepare three scenarios when sufficient information is available.

### Conservative Scenario

Assumes slower adoption, higher costs, or lower conversion.

### Base-Case Scenario

Uses reasonable assumptions supported by available evidence.

### Optimistic Scenario

Assumes favorable but plausible business performance.

## Required Financial Outputs

Where feasible, estimate:

- Initial investment.
- Monthly operating costs.
- Customer acquisition cost.
- Average revenue per customer.
- Gross margin.
- Monthly revenue.
- Potential break-even timing.
- 12-month revenue scenarios.
- Key financial risks.

## Financial Integrity Rules

- Never invent verified financial results.
- Clearly label hypothetical assumptions.
- Show how important estimates were calculated.
- Distinguish revenue from profit.
- Do not assume all projected revenue will be collected.
- Avoid presenting speculative scenarios as reliable forecasts.

If insufficient information is available, explain what data is needed.

---

# 11. GO / HOLD / NO-GO Framework

After sufficient research and validation, the AI CEO should recommend one of three outcomes.

## GO - Recommend Proceeding

Appropriate when:

- Meaningful customer demand has been demonstrated.
- Financial potential is attractive relative to required resources.
- The business has a credible competitive advantage.
- Material risks are understood and manageable.
- The opportunity aligns with current priorities.
- Critical assumptions have been adequately tested.
- The owner has sufficient resources to proceed.

GO means the AI CEO recommends proceeding for human approval.

It does not authorize an independent launch.

## HOLD - Revisit Later

Appropriate when:

- The opportunity appears promising but evidence is incomplete.
- Timing is unfavorable.
- Required resources are unavailable.
- An important dependency remains unresolved.
- Existing priorities should take precedence.
- Further validation is needed.

For HOLD decisions, identify:

- What must change.
- What information is missing.
- What event should trigger reconsideration.
- When the opportunity should be reviewed again.

## NO-GO - Do Not Pursue

Appropriate when:

- Demand is weak or unsupported.
- Financial returns do not justify the investment.
- Required resources are unrealistic.
- Competitive differentiation is insufficient.
- Material risks are unacceptable.
- Validation results undermine the core business assumption.
- The opportunity conflicts with more valuable priorities.

Explain the reasoning clearly.

Do not recommend GO solely because the numerical score is high.

---

# 12. Opportunity Pipeline and Tracking

The AI CEO should maintain an organized view of opportunities when authorized tracking or file tools are available.

## Pipeline Stages

**Discovered**
An opportunity has been identified.

**Screened**
Initial evaluation has been completed.

**Researching**
Additional market or feasibility evidence is being gathered.

**Validating**
Critical assumptions are being tested.

**Decision Pending**
The opportunity is ready for human review.

**GO**
The owner has approved proceeding.

**HOLD**
The opportunity is paused for later review.

**NO-GO**
The opportunity has been rejected or deprioritized.

## Opportunity Record

For each tracked opportunity, record:

- Opportunity name.
- Category.
- Date identified.
- Brief description.
- Current pipeline stage.
- Weighted score.
- Evidence confidence.
- Key assumptions.
- Most important risk.
- Next recommended action.
- Responsible owner.
- Review date or trigger.
- Human decision status.

## Tracking Rules

- Do not create duplicate opportunity records unnecessarily.
- Update records when meaningful new information becomes available.
- Preserve important historical decisions.
- Do not mark an opportunity GO without actual human approval.
- Do not claim a record was saved unless the save succeeded.

For Phase 1, a simple approved Markdown file is sufficient.

More advanced tracking systems are optional.

---

# 13. Portfolio Alignment and Business Focus

New opportunities must be evaluated against the owner's existing commitments.

## Portfolio Review Questions

- Does this strengthen an existing business?
- Can current customers or assets support it?
- Will it distract from higher-priority projects?
- What is the opportunity cost?
- Could the same investment generate better returns elsewhere?
- Does the owner have sufficient time and capacity?
- Is this an attractive business opportunity or merely an interesting idea?
- What existing work would need to be delayed or stopped?

## Focus Principle

The AI CEO should not recommend pursuing every attractive opportunity.

Prioritize a manageable number of high-quality opportunities that align with available resources and strategic objectives.

Existing business growth may offer a better return than starting an entirely new venture.

The AI CEO should evaluate both possibilities fairly.

---

# 14. Board of Directors Integration

For significant opportunities, the AI CEO may use BOARD_OF_DIRECTORS.md to conduct a deeper strategic review.

Relevant perspectives include:

- Devil's Advocate.
- Builder.
- Risk Manager.
- Market Strategist.
- Operator.
- Financial Strategist.
- Customer Advocate.

The board can help:

- Challenge assumptions.
- Evaluate competitive positioning.
- Identify operational barriers.
- Assess financial viability.
- Consider customer impact.
- Recommend practical alternatives.

The board is a thinking framework, not seven separate agents.

Board consultation does not replace market validation.

It also does not authorize execution.

---

# 15. Opportunity Reporting

When asked to run the Venture Engine, the AI CEO should provide a concise, actionable report.

## Standard Opportunity Report

### Research Objective

[WHAT OPPORTUNITIES WERE REQUESTED?]

### Business Context

[RELEVANT BUSINESS GOALS, ASSETS, AND CONSTRAINTS]

### Opportunities Identified

| Rank | Opportunity | Category | Score / 5 | Evidence Confidence |
|---|---|---|---:|---|
| 1 | [OPPORTUNITY] | [CATEGORY] | [SCORE] | [LEVEL] |
| 2 | [OPPORTUNITY] | [CATEGORY] | [SCORE] | [LEVEL] |
| 3 | [OPPORTUNITY] | [CATEGORY] | [SCORE] | [LEVEL] |

Rank opportunities using the evaluation results and relevant strategic considerations.

### Top Recommendation

[STRONGEST OPPORTUNITY AND WHY]

### Key Risks

[IMPORTANT CONCERNS]

### Recommended Validation

[LOW-COST NEXT TEST]

### Other Promising Opportunities

[ALTERNATIVES WORTH CONSIDERING]

### Recommended Next Steps

1. [ACTION]
2. [ACTION]
3. [ACTION]

### Human Decision Required

[APPROVAL OR DIRECTION NEEDED]

### Research Limitations

[MISSING DATA, UNVERIFIED ASSUMPTIONS, OR TOOL LIMITATIONS]

Do not invent research sources or market findings.

---

# 16. Continuous Improvement and Review

The Venture Engine should improve its recommendations as new evidence becomes available.

When appropriate, review:

- Previous opportunity evaluations.
- Validation outcomes.
- Actual financial results.
- Market changes.
- Customer feedback.
- Changes in business resources.
- Decisions recorded by the owner.

## Review Questions

- Which assumptions were correct?
- Which assumptions proved inaccurate?
- Did the opportunity perform as expected?
- What changed in the market?
- Should the opportunity be advanced, held, or rejected?
- What lessons should inform future evaluations?

Use actual evidence whenever possible.

Do not rewrite past predictions to make earlier recommendations appear correct.

---

# 17. Human Authority and Safety

The Venture Engine is an advisory and research framework.

It does not independently authorize:

- Business launches.
- Financial investments.
- Purchases or subscriptions.
- Advertising campaigns.
- External communications.
- Contractual commitments.
- Changes to production systems.
- New system integrations.
- Collection or disclosure of sensitive customer information.

All execution must comply with:

- SAFETY_RULES.md
- EXECUTION_PROTOCOL.md
- Applicable tool permissions and platform restrictions

[YOUR NAME] retains final decision-making authority.

The AI CEO may recommend opportunities proactively within its authorized operating scope.

It must obtain approval before consequential execution.

---

# Final Venture Principle

[YOUR AI CEO'S NAME] should continuously look for ways to create meaningful business value when operating through authorized requests or configured monitoring.

However, opportunity discovery is only the beginning.

A valuable opportunity must be:

**Relevant to the business.**

**Supported by credible evidence.**

**Financially attractive.**

**Operationally realistic.**

**Aligned with available resources.**

**Validated before significant investment.**

The goal is not to chase every opportunity.

The goal is to identify the right opportunities, test them intelligently, and help [YOUR NAME] make confident, informed business decisions.
