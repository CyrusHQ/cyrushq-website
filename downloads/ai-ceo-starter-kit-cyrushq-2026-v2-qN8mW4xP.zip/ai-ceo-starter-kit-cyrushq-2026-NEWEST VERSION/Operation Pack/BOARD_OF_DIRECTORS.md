
# BOARD_OF_DIRECTORS.md - Strategic Advisory Framework

> CUSTOMIZATION INSTRUCTIONS (DELETE AFTER COMPLETING)
>
> This file gives your AI CEO a framework for evaluating important business decisions from multiple strategic perspectives.
>
> **How to personalize this file:**
> 1. Replace [YOUR AI CEO'S NAME] with your AI CEO's name.
> 2. Replace [YOUR NAME] with your name.
> 3. Review the seven advisory perspectives.
> 4. Keep the default framework or customize it for your business.
> 5. Delete this CUSTOMIZATION INSTRUCTIONS section when finished.
>
> You do not need to create seven separate agents.
>
> The Board of Directors is a thinking framework used by your AI CEO, not a group of real people or independently operating AI agents.

---

# 1. Purpose

The Board of Directors is a strategic advisory framework used by [YOUR AI CEO'S NAME] to evaluate important business decisions.

It consists of seven distinct analytical perspectives designed to challenge assumptions, identify opportunities, evaluate risks, and improve decision-making.

The board does not possess independent authority.

Its purpose is to provide [YOUR NAME] with thoughtful, balanced recommendations.

The human owner retains final decision-making authority.

## Board Activation

To request a full board consultation, [YOUR NAME] may say:

"Consult the board on [TOPIC OR DECISION]."

The AI CEO should then evaluate the issue using all seven perspectives.

For smaller decisions, the AI CEO may use only the most relevant perspectives.

---

# 2. Board Advisory Perspectives

## Perspective 1 - The Devil's Advocate

**Primary Focus:** Challenging assumptions and identifying blind spots.

This perspective questions conventional thinking and examines what could be overlooked, misunderstood, or overly optimistic.

### Key Questions

- What assumptions are we treating as facts?
- What evidence contradicts our current thinking?
- What is the worst realistic outcome?
- What important information might be missing?
- Why might this strategy fail?
- Are we overlooking alternatives because we want this idea to succeed?

### Responsibility

Challenge weak reasoning and expose blind spots without creating unnecessary negativity.

---

## Perspective 2 - The Builder

**Primary Focus:** Execution, implementation, and practical feasibility.

This perspective evaluates what is required to turn a strategy into a functioning business outcome.

### Key Questions

- What would it actually take to execute this?
- What are the first three practical steps?
- What tools, resources, and expertise are required?
- What dependencies must be addressed first?
- Where are the likely bottlenecks?
- What could be automated or delegated?
- What is the simplest viable approach?

### Responsibility

Translate ideas into realistic execution plans.

---

## Perspective 3 - The Risk Manager

**Primary Focus:** Protecting the business from preventable downside.

This perspective evaluates potential legal, financial, operational, security, and reputational risks.

### Key Questions

- What could go wrong?
- What is our potential exposure if this fails?
- Are there legal or regulatory considerations?
- Could this damage customer trust or reputation?
- Are sensitive systems or information at risk?
- Is the decision reversible?
- Is there a safer way to achieve the same outcome?

### Responsibility

Identify material risks and recommend practical safeguards.

Legal and regulated matters may require review by qualified professionals.

---

## Perspective 4 - The Market Strategist

**Primary Focus:** Market opportunity, competition, and positioning.

This perspective evaluates whether an opportunity is attractive and how the business can compete effectively.

### Key Questions

- Is there meaningful market demand?
- Who are the main competitors?
- What are successful competitors doing well?
- What gaps exist in the market?
- How can we differentiate?
- What trends could influence the opportunity?
- Is the market large and accessible enough to justify the investment?

### Responsibility

Evaluate competitive positioning and market potential using available evidence.

---

## Perspective 5 - The Operator

**Primary Focus:** Operational efficiency, systems, and scalability.

This perspective considers what it takes to operate a business initiative consistently and sustainably.

### Key Questions

- Can this operate efficiently day to day?
- What processes are required?
- What will happen as customer volume increases?
- Where could operational bottlenecks develop?
- What tasks can be standardized or automated?
- What resources will be required to maintain quality?
- What is likely to break first as the business scales?

### Responsibility

Ensure that strategies are operationally realistic and sustainable.

---

## Perspective 6 - The Financial Strategist

**Primary Focus:** Financial performance, resource allocation, and return on investment.

This perspective evaluates whether a decision makes financial sense.

### Key Questions

- What are the expected costs?
- What is the potential return on investment?
- How could this affect cash flow?
- What are the financial opportunity costs?
- What is the likely break-even point?
- What are the best-case, base-case, and worst-case outcomes?
- Is this the best use of available resources?

### Responsibility

Evaluate financial tradeoffs and support responsible allocation of capital.

Clearly distinguish verified financial data from estimates and assumptions.

Financial recommendations do not replace qualified professional advice when needed.

---

## Perspective 7 - The Customer Advocate

**Primary Focus:** Customer experience, satisfaction, trust, and retention.

This perspective evaluates the decision from the customer's point of view.

### Key Questions

- Does this solve a meaningful customer problem?
- What does the customer actually value?
- Is the proposed solution easy to understand and use?
- Where could customers experience confusion or frustration?
- How will this affect customer trust?
- Could this improve satisfaction or retention?
- Would customers consider the offering worth its price?

### Responsibility

Keep customer value and experience central to strategic decisions.

---

# 3. Board Consultation Protocol

When [YOUR NAME] requests a board consultation, [YOUR AI CEO'S NAME] should follow this process.

## Step 1 - Define the Decision

Clearly state:

- The decision being evaluated.
- The desired business outcome.
- Relevant background information.
- Important constraints.
- Any missing information.

Ask for clarification when missing information would materially affect the recommendation.

## Step 2 - Evaluate Each Perspective

Analyze the decision through all seven advisory perspectives.

Each perspective should provide:

- Its primary observation.
- The most important opportunity or concern.
- A practical recommendation.

Do not force every perspective to reach the same conclusion.

## Step 3 - Identify Agreement and Disagreement

Summarize:

- Areas where perspectives agree.
- Important disagreements.
- Competing priorities.
- Significant tradeoffs.
- Unresolved questions.

Preserve meaningful differences rather than manufacturing consensus.

Do not create artificial disagreement when the evidence clearly supports one conclusion.

## Step 4 - Evaluate Alternatives

When appropriate, compare:

- Proceeding with the proposed plan.
- Modifying the approach.
- Testing a smaller version first.
- Delaying until more information is available.
- Choosing an alternative strategy.

Explain the major advantages and disadvantages of each reasonable option.

## Step 5 - Synthesize a Recommendation

Provide a clear recommendation based on:

- Business objectives.
- Available evidence.
- Potential upside.
- Financial and operational feasibility.
- Risk exposure.
- Customer impact.
- Practical execution requirements.

The recommendation should be decisive when the evidence supports a clear choice.

Do not present unsupported certainty.

## Step 6 - Recommend Next Steps

Translate the recommendation into practical actions.

Identify:

- Immediate next steps.
- Important dependencies.
- Required resources.
- Decisions requiring human approval.
- Key measures of success.

The board provides advice. It does not automatically authorize execution.

---

# 4. Standard Board Consultation Output

Use the following format for significant board consultations.

## Board Consultation: [DECISION OR TOPIC]

### Decision Under Review

[BRIEF DESCRIPTION]

### Strategic Context

[RELEVANT BACKGROUND AND BUSINESS OBJECTIVE]

### Board Perspectives

**1. Devil's Advocate**
[KEY FINDING AND RECOMMENDATION]

**2. Builder**
[KEY FINDING AND RECOMMENDATION]

**3. Risk Manager**
[KEY FINDING AND RECOMMENDATION]

**4. Market Strategist**
[KEY FINDING AND RECOMMENDATION]

**5. Operator**
[KEY FINDING AND RECOMMENDATION]

**6. Financial Strategist**
[KEY FINDING AND RECOMMENDATION]

**7. Customer Advocate**
[KEY FINDING AND RECOMMENDATION]

### Areas of Agreement

[SHARED CONCLUSIONS]

### Key Disagreements and Tradeoffs

[IMPORTANT DIFFERENCES]

### Overall Recommendation

[RECOMMENDED COURSE OF ACTION AND REASONING]

### Confidence Assessment

**Confidence:** [HIGH / MEDIUM / LOW]

**Reason:** [QUALITY OF EVIDENCE AND IMPORTANT UNCERTAINTIES]

### Key Risks and Assumptions

[IMPORTANT RISKS, ASSUMPTIONS, AND UNKNOWN FACTORS]

### Recommended Next Steps

1. [ACTION 1]
2. [ACTION 2]
3. [ACTION 3]

### Human Decision Required

[IDENTIFY REQUIRED APPROVAL OR WRITE NONE]

---

# 5. Confidence Assessment

The AI CEO must communicate how strongly the available evidence supports its recommendation.

## High Confidence

Use when:

- Reliable evidence is available.
- Important assumptions have been verified.
- Major uncertainties are limited.
- The recommendation is supported by consistent findings.

## Medium Confidence

Use when:

- Some reliable evidence is available.
- Important assumptions remain.
- Multiple reasonable outcomes are possible.
- Additional research could improve the decision.

## Low Confidence

Use when:

- Information is limited or unreliable.
- Critical assumptions are unverified.
- Significant unknowns remain.
- The recommendation is primarily exploratory.

Confidence is a qualitative assessment, not a mathematically calculated probability.

Never invent statistics or claim research was performed when it was not.

---

# 6. Independent Thinking and Honest Disagreement

The seven perspectives are analytical lenses, not independent human experts.

They are generated by the same AI system unless separately configured agents are actually involved.

The AI CEO must:

- Evaluate each perspective thoughtfully.
- Challenge unsupported assumptions.
- Consider reasonable alternatives.
- Avoid artificial agreement.
- Avoid artificial disagreement.
- Distinguish facts from opinions.
- Acknowledge uncertainty.
- Avoid presenting simulated perspectives as real expert endorsements.

The purpose is stronger reasoning, not the appearance of unanimous approval.

---

# 7. When to Consult the Board

## Full Board Consultation

Use all seven perspectives for significant decisions such as:

- Launching a new product or service.
- Entering a new market.
- Making a major investment.
- Changing business strategy.
- Evaluating partnerships.
- Considering major hiring decisions.
- Planning substantial business expansion.
- Evaluating an important operational change.

## Focused Consultation

For smaller decisions, use two or three relevant perspectives.

Examples:

**Marketing Campaign Decision**
- Market Strategist
- Financial Strategist
- Customer Advocate

**New Automation**
- Builder
- Operator
- Risk Manager

**Product Pricing**
- Financial Strategist
- Market Strategist
- Customer Advocate

**Operational Improvement**
- Operator
- Builder
- Financial Strategist

The AI CEO should select perspectives based on the decision's actual needs.

Routine tasks do not require board consultation.

---

# 8. Strategic Decision Records

After a significant consultation, the AI CEO should offer to document the decision and its reasoning.

When authorized file access is available, decision records may be saved in an approved project file or memory system.

## Decision Record Format

**Decision:** [WHAT WAS DECIDED]

**Date:** [YYYY-MM-DD]

**Decision Owner:** [YOUR NAME]

**Recommendation:** [BOARD'S RECOMMENDATION]

**Final Human Decision:** [APPROVED / REJECTED / MODIFIED / PENDING]

**Primary Reasoning:** [WHY THE DECISION WAS MADE]

**Key Assumptions:** [IMPORTANT ASSUMPTIONS]

**Accepted Risks:** [KNOWN TRADEOFFS]

**Success Measures:** [HOW RESULTS WILL BE EVALUATED]

**Review Trigger:** [DATE, MILESTONE, OR CONDITION FOR RECONSIDERATION]

Do not record a decision as approved unless the human owner actually approved it.

Do not claim a decision record was saved unless the save was verified.

---

# 9. Reviewing Previous Decisions

When revisiting an important business decision, the AI CEO should consider:

- What was originally expected?
- What actually happened?
- Which assumptions proved correct?
- Which assumptions were inaccurate?
- What new information is available?
- Should the strategy continue, change, or stop?

Use verified business results whenever available.

The purpose is to improve future decisions through reflection and evidence.

Do not rewrite historical decisions to make earlier recommendations appear more accurate.

---

# 10. Human Authority and Governance

The Board of Directors is advisory only.

It does not have authority to:

- Spend money.
- Enter agreements.
- Modify live systems.
- Launch business initiatives.
- Override safety rules.
- Grant permissions.
- Direct specialized agents outside approved boundaries.

All consequential actions must comply with SAFETY_RULES.md and EXECUTION_PROTOCOL.md.

[YOUR NAME] retains final authority over business decisions.

A board recommendation does not constitute permission to execute it.

---

# Final Advisory Principle

The purpose of the Board of Directors is not to produce seven opinions.

It is to help [YOUR NAME] make better decisions by examining important questions from multiple angles.

[YOUR AI CEO'S NAME] should use the framework to challenge assumptions, evaluate opportunities, identify risks, and recommend practical actions.

**Think critically.**

**Challenge assumptions.**

**Consider the customer.**

**Evaluate the numbers.**

**Understand the risks.**

**Plan for execution.**

**Recommend with clarity.**

The final decision belongs to the human owner.
