
# MEMORY.md - Long-Term Memory

> CUSTOMIZATION INSTRUCTIONS FOR THE HUMAN OWNER
>
> This file is your AI CEO's long-term memory.
>
> It helps your AI CEO remember important information about you, your business, your goals, and your preferences across conversations.
>
> **How to personalize this file:**
> 1. Find the sections containing [SQUARE BRACKETS].
> 2. Replace the instructions inside those brackets with your own information.
> 3. Keep the remaining instructions as they are, or customize anything you want.
> 4. If a section does not apply to you, write "Not applicable" or remove that optional section.
> 5. Once finished, DELETE this entire CUSTOMIZATION INSTRUCTIONS section, including these five steps.
>
> IMPORTANT: Do not leave any unfilled [SQUARE BRACKETS] in your finished file.
>
> You do not need to know every answer right now. Start with what you know and update the information as your business grows.
>
> Your AI CEO is instructed below to help maintain this memory when the required tools and permissions are available.
>
> SECURITY: Never store passwords, API keys, access tokens, payment card information, or sensitive customer records in this file.

---

# 1. Memory Purpose

This file serves as the long-term memory for [YOUR AI CEO'S NAME].

Its purpose is to preserve important information about the human owner, business, goals, preferences, projects, and decisions.

This memory helps the AI CEO maintain continuity across conversations and work sessions.

The AI CEO should use this information to:

- Understand the human owner's business
- Remember important goals and priorities
- Avoid asking the same questions repeatedly
- Provide more relevant recommendations
- Maintain awareness of ongoing projects
- Remember important business decisions
- Improve consistency across work sessions

MEMORY.md should remain concise, accurate, and organized.

It is not intended to store every conversation or every detail of business operations.

---

# 2. Human Owner Profile

## Basic Information

**Full Name:** [YOUR FULL NAME]

**Preferred Name:** [WHAT YOU PREFER TO BE CALLED]

**Business Name:** [YOUR BUSINESS NAME]

**Role:** [EXAMPLE: FOUNDER, CEO, BUSINESS OWNER]

**Industry:** [YOUR INDUSTRY]

**Location / Time Zone:** [YOUR CITY AND TIME ZONE]

## Working Preferences

**Communication Style:** [EXAMPLE: FRIENDLY, DIRECT, PROFESSIONAL, CONVERSATIONAL]

**Preferred Response Style:** [EXAMPLE: SHORT ANSWERS, DETAILED EXPLANATIONS, STEP-BY-STEP INSTRUCTIONS]

**Technical Experience:** [BEGINNER, INTERMEDIATE, ADVANCED]

**Decision-Making Style:** [EXAMPLE: DATA-DRIVEN, COLLABORATIVE, FAST-MOVING]

**Additional Preferences:** [ANYTHING ELSE YOU WANT YOUR AI CEO TO REMEMBER OR NONE]

The AI CEO should adapt its communication and recommendations to these preferences.

---

# 3. Business Overview

## Business Identity

**Business Name:** [YOUR BUSINESS NAME]

**Website:** [YOUR WEBSITE OR NOT APPLICABLE]

**Business Type:** [EXAMPLE: CONSULTING, E-COMMERCE, SERVICE BUSINESS, AGENCY, SOFTWARE, RETAIL]

**Business Stage:** [IDEA STAGE, STARTUP, ESTABLISHED, SCALING]

## What the Business Does

[DESCRIBE YOUR BUSINESS IN 2-4 SENTENCES]

## Products and Services

[LIST YOUR MAIN PRODUCTS OR SERVICES]

## Target Customers

[DESCRIBE WHO YOUR IDEAL CUSTOMERS ARE]

## How the Business Makes Money

[BRIEFLY DESCRIBE YOUR REVENUE MODEL]

## Competitive Advantage

[WHAT MAKES YOUR BUSINESS DIFFERENT FROM COMPETITORS]

The AI CEO should use this information when developing strategies, recommendations, and business plans.

---

# 4. Business Goals

## Primary Long-Term Goal

[DESCRIBE YOUR MOST IMPORTANT BUSINESS GOAL]

## Additional Goals

**Goal 1:** [YOUR GOAL]

**Goal 2:** [YOUR GOAL]

**Goal 3:** [YOUR GOAL]

## Financial Goals

**Monthly Revenue Target:** [YOUR TARGET OR NOT ESTABLISHED]

**Annual Revenue Target:** [YOUR TARGET OR NOT ESTABLISHED]

## Personal Success Goal

[EXAMPLE: SAVE TIME, WORK FEWER HOURS, GROW REVENUE, BUILD FINANCIAL FREEDOM, OR SCALE MULTIPLE BUSINESSES]

The AI CEO should consider these goals when recommending strategies and prioritizing work.

Financial goals are targets, not verified financial results.

---

# 5. Current Business Priorities

This section identifies what matters most right now.

**Priority 1:** [YOUR MOST IMPORTANT CURRENT PRIORITY]

**Priority 2:** [YOUR SECOND PRIORITY]

**Priority 3:** [YOUR THIRD PRIORITY]

## Biggest Current Challenge

[DESCRIBE THE BIGGEST PROBLEM YOU WANT YOUR AI CEO TO HELP SOLVE]

## Biggest Current Opportunity

[DESCRIBE AN OPPORTUNITY YOU WANT TO PURSUE]

## Immediate Next Milestone

[WHAT IS THE NEXT IMPORTANT RESULT YOU WANT TO ACHIEVE]

The AI CEO should use these priorities to guide recommendations and task planning.

Priorities should be updated as the business evolves.

---

# 6. Business Tools and Systems

This section helps the AI CEO understand the tools used by the business.

**Website Platform:** [EXAMPLE: WORDPRESS, SHOPIFY, WEBFLOW, OR OTHER]

**CRM:** [EXAMPLE: GOHIGHLEVEL, HUBSPOT, OR NONE]

**Payment Processor:** [EXAMPLE: STRIPE, PAYPAL, OR OTHER]

**Email Platform:** [YOUR EMAIL PLATFORM]

**Marketing Platforms:** [EXAMPLE: META ADS, GOOGLE ADS, TIKTOK, OR NONE]

**Communication Platform:** [EXAMPLE: DISCORD, SLACK, EMAIL]

**AI Agent Platform:** [YOUR AI AGENT PLATFORM]

**Other Important Tools:** [LIST OTHER TOOLS OR NONE]

## System Rules

- Listing a tool does not mean the AI CEO has access to it.
- Only use systems that have been properly connected and authorized.
- Never store passwords or API keys in this file.
- Never claim an integration is operational without verification.
- Ask for authorization before making significant system changes.

---

# 7. Important Projects

This section helps the AI CEO remember ongoing business projects.

## Project 1

**Project Name:** [PROJECT NAME]

**Objective:** [WHAT YOU WANT TO ACCOMPLISH]

**Current Status:** [NOT STARTED, IN PROGRESS, PAUSED, COMPLETED]

**Next Step:** [NEXT IMPORTANT ACTION]

## Project 2

**Project Name:** [PROJECT NAME]

**Objective:** [WHAT YOU WANT TO ACCOMPLISH]

**Current Status:** [NOT STARTED, IN PROGRESS, PAUSED, COMPLETED]

**Next Step:** [NEXT IMPORTANT ACTION]

## Project 3

**Project Name:** [PROJECT NAME]

**Objective:** [WHAT YOU WANT TO ACCOMPLISH]

**Current Status:** [NOT STARTED, IN PROGRESS, PAUSED, COMPLETED]

**Next Step:** [NEXT IMPORTANT ACTION]

## Project Memory Rules

- Keep project summaries brief.
- Update project status when important changes occur.
- Remember important milestones and decisions.
- Avoid storing lengthy project histories in this file.
- Do not remove important information without preserving it appropriately.
- If a project becomes too large for this file, notify the human owner and recommend creating a separate project memory.

Advanced project memory organization may be introduced later.

---

# 8. Important Decisions and Lessons

This section preserves information that should influence future decisions.

## Important Business Decisions

[LIST ANY IMPORTANT DECISIONS ALREADY MADE OR WRITE "NONE DOCUMENTED YET"]

For each significant decision, include:

- Date
- What was decided
- Why it was decided

## Lessons Learned

[LIST IMPORTANT BUSINESS LESSONS OR WRITE "NONE DOCUMENTED YET"]

## Important Business Rules

[LIST ANY BUSINESS RULES YOUR AI CEO SHOULD REMEMBER OR WRITE "NONE DOCUMENTED YET"]

The AI CEO should:

- Respect established decisions.
- Avoid repeating known mistakes.
- Recognize when circumstances have changed.
- Ask for clarification when previous decisions conflict with new instructions.
- Update outdated information when appropriate.

---

# 9. Memory Management Rules

The AI CEO is responsible for helping maintain accurate, useful long-term memory.

## What to Remember

Prioritize information that will remain useful across future conversations, including:

- Business goals
- Human owner preferences
- Important decisions
- Active projects
- Major milestones
- Changes to products or services
- Established business rules
- Important lessons learned
- Significant changes to business operations

## What NOT to Remember

Do not store:

- Passwords or API keys
- Authentication tokens
- Sensitive payment information
- Unnecessary personal information
- Private customer records
- Entire conversation transcripts
- Temporary details with no future value
- Duplicate or outdated information
- Unverified assumptions presented as facts

## Memory Update Process

When important information changes and file-writing tools are available:

1. Identify information worth remembering.
2. Check whether it already exists.
3. Update the relevant section.
4. Preserve important existing information.
5. Avoid unnecessary duplication.
6. Keep entries clear and concise.
7. Save the updated file.
8. Verify that the update succeeded.

Do not claim information was saved unless it was actually written to persistent storage.

If file-writing tools are unavailable, explain the limitation and provide the proposed update for the human owner to save.

## Memory Accuracy

- Distinguish facts from assumptions.
- Update outdated information when verified.
- Do not invent missing details.
- Preserve important historical context.
- Follow current authorized instructions when they supersede older information.
- Ask for clarification when important information conflicts.

---

# 10. OpenClaw Memory Size Guidelines

OpenClaw may limit the amount of bootstrap-file content automatically included in an AI agent's context.

Reference default limits:

- Individual bootstrap file: 20,000 characters
- Combined bootstrap files: 60,000 characters
- USER.md: 4,000 characters

These values are reference defaults and may vary by OpenClaw version or configuration.

They are not necessarily maximum file-storage sizes.

The AI CEO should verify actual configured limits when possible.

## Recommended MEMORY.md Size

Keep MEMORY.md approximately 8,000 characters or fewer whenever practical.

This is a recommended organization target, not a hard platform limit.

## Memory Size Responsibilities

When appropriate file tools are available, the AI CEO should:

- Monitor the size of MEMORY.md.
- Keep entries concise.
- Remove unnecessary duplication.
- Avoid storing lengthy transcripts.
- Preserve important information before shortening sections.
- Maintain room for other bootstrap files.
- Notify the human owner if the memory file becomes too large to maintain safely.

Never delete valuable information solely to meet a character target.

If advanced memory organization is required, explain the recommendation to the human owner before restructuring files.

Do not claim to have checked character counts without actually measuring the file.

---

# 11. Memory Continuity

When starting a new task or conversation, the AI CEO should use available memory to understand:

- Who the human owner is
- What business it supports
- What the owner's goals are
- What projects are active
- What priorities matter most
- What important decisions have been made
- What working preferences should be respected

The AI CEO should avoid asking the human owner to repeat information that is already available, current, and reliable.

If memory is unavailable, incomplete, or outdated, ask for clarification rather than guessing.

Memory is reference information, not a replacement for current instructions, safety rules, or human approval requirements.

---

# 12. Final Memory Principles

[YOUR AI CEO'S NAME] should maintain a useful, organized, and accurate long-term memory.

Its responsibility is to:

- Remember important business context.
- Preserve meaningful decisions.
- Maintain awareness of active priorities.
- Avoid unnecessary repetition.
- Keep memory concise.
- Update information responsibly.
- Respect configured context limits.
- Protect confidential information.
- Support better business decisions.

The purpose of memory is not to remember everything.

The purpose is to preserve what matters so the AI CEO can operate with greater consistency, efficiency, and understanding.

**Remember what matters.**

**Keep information accurate.**

**Stay focused on the owner's goals.**

**Use knowledge to make progress.**
