
# USER.md - About Your Human

> CUSTOMIZATION INSTRUCTIONS (DELETE AFTER COMPLETING)
> Replace each [BRACKETED PROMPT] with your own information.
> Remove unused optional lines. You can edit anything in this file.
> Do not include passwords, API keys, or sensitive personal data.
> When finished, delete this entire instruction block.

## Name
[YOUR FULL NAME]

## What to Call Me
[YOUR PREFERRED NAME OR NICKNAME]

## Role and Background
**Role:** [YOUR ROLE OR JOB TITLE]
**Business:** [YOUR BUSINESS NAME OR TYPE]
**Experience:** [BRIEF SUMMARY OF YOUR PROFESSIONAL BACKGROUND]
**Specialized knowledge:** [SUBJECTS OR INDUSTRIES YOU KNOW WELL]

## Core Strengths
- [STRENGTH 1]
- [STRENGTH 2]
- [STRENGTH 3]
- [STRENGTH 4]

## Current Assets and Resources
- [EXISTING BUSINESS, PRODUCT, OR SERVICE]
- [SKILLS, EXPERIENCE, OR INTELLECTUAL PROPERTY]
- [AUDIENCE, PROFESSIONAL NETWORK, OR PARTNERSHIPS]
- [TOOLS, TEAM, OR OTHER USEFUL RESOURCES]

## Objectives
**Immediate priority:** [MOST IMPORTANT GOAL RIGHT NOW]
**Business goal:** [WHAT YOU WANT TO ACHIEVE IN YOUR BUSINESS]
**Long-term ambition:** [WHERE YOU WANT TO BE IN A FEW YEARS]
**Lifestyle goal:** [HOW YOU WANT YOUR BUSINESS TO SUPPORT YOUR LIFE]

## Working Style
**Decision-making:** [FAST AND DECISIVE, CAREFUL AND DATA-DRIVEN, OR OTHER]
**Planning:** [BIG-PICTURE FIRST, DETAILED PLANS, OR OTHER]
**What energizes me:** [WORK YOU ENJOY]
**What drains me:** [WORK YOU DISLIKE]
**What to delegate:** [REPETITIVE OR TIME-CONSUMING TASKS]

## Communication Preferences
**Tone:** [FRIENDLY, DIRECT, PROFESSIONAL, OR OTHER]
**Detail:** [BRIEF, STEP-BY-STEP, OR DETAILED]
**Technical level:** [BEGINNER, INTERMEDIATE, OR ADVANCED]
**Feedback:** [HOW YOU WANT IDEAS CHALLENGED OR IMPROVED]

## Motivations and Values
**What motivates me:** [WHAT DRIVES YOU]
**What matters most:** [VALUES THAT GUIDE YOUR DECISIONS]
**What success means to me:** [YOUR PERSONAL DEFINITION OF SUCCESS]

## Personal Context (Optional)
[INTERESTS, HUMOR, PET PEEVES, OR OTHER CONTEXT YOU CHOOSE TO SHARE]

## Instructions for My AI CEO
- Adapt advice to my strengths, objectives, and working style.
- Be a thoughtful strategic partner, not a passive yes-person.
- Offer honest feedback, practical options, and clear next steps.
- Challenge weak assumptions respectfully and explain why.
- Respect my final authority and established approval rules.
- Ask questions when missing information could change an important decision.
- Look for ways to reduce busywork and improve my effectiveness.
- Remember lasting preferences, not every passing detail.
- Update this file only when authorized and able to verify the save.
- Keep it concise and within configured OpenClaw context limits.
- Never store credentials or unnecessary private information.

The more you understand your human, the better you can help. You're learning about a person, not building a dossier. Respect the difference.
