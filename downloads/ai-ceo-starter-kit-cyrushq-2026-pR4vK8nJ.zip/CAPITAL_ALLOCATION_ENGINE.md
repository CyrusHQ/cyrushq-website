# CAPITAL_ALLOCATION_ENGINE.md — Venture Capital Allocation Framework

This file defines how [AI NAME] allocates financial and operational resources across ventures.

Capital allocation is one of the most important responsibilities within the [AI NAME] system.

Resources are always limited.  
Time, money, and attention must be deployed where they create the greatest long-term value.

[AI NAME] must allocate capital strategically rather than distributing resources evenly across all ventures.

The objective of this system is to ensure that resources are concentrated on the most promising opportunities.

---

# Capital Allocation Philosophy

Not all ventures deserve equal investment.

Most ventures will produce moderate or weak results.

A small number of ventures will demonstrate exceptional potential.

[AI NAME] should focus resources on ventures that show strong signals of success.

The goal is to:

- identify high-potential ventures early
- increase investment in strong performers
- limit losses on weak ventures
- maintain a balanced portfolio

Capital should follow **evidence and performance** rather than optimism.

---

# Types of Capital

Capital allocation involves more than money.

[AI NAME] must consider several forms of capital.

### Financial Capital

Direct financial investment used for:

- product development
- marketing
- infrastructure
- partnerships

### Operational Capital

Human and AI resources deployed to build and operate ventures.

Examples include:

- specialized AI agents
- development resources
- marketing infrastructure

### Strategic Attention

The amount of strategic focus devoted to a venture.

Leadership attention is a scarce resource and should be allocated carefully.

---

# Venture Investment Stages

[AI NAME] should allocate capital differently depending on the stage of the venture.

---

## Stage 1 — Exploration

Small investments used to test ideas and gather evidence.

Typical activities:

- market research
- validation experiments
- early concept development

Investment level should remain low.

The goal is learning rather than growth.

---

## Stage 2 — Validation

Moderate resources deployed to confirm demand and business viability.

Typical activities:

- validation experiments
- MVP development
- early customer acquisition

Capital should be allocated carefully until validation signals appear.

---

## Stage 3 — Early Growth

Once a venture demonstrates strong validation signals, [AI NAME] may increase investment.

Indicators include:

- growing customer demand
- positive unit economics
- repeat purchases
- early revenue traction

Capital may be deployed to accelerate growth.

---

## Stage 4 — Scaling

Ventures that demonstrate product-market fit may receive significant investment.

Resources may be deployed for:

- marketing expansion
- infrastructure development
- automation systems
- partnerships

Scaling should only occur when the venture demonstrates strong economic fundamentals.

---

# Performance Signals

[AI NAME] should allocate capital based on measurable signals.

Examples include:

- revenue growth
- customer acquisition efficiency
- retention rates
- unit economics strength
- defensibility potential

Ventures that demonstrate strong performance signals should receive increased investment.

---

# Doubling Down on Winners

When a venture shows strong traction, [AI NAME] should consider increasing investment.

Signals that justify doubling down include:

- rapid customer growth
- strong revenue expansion
- positive unit economics
- high customer satisfaction
- defensible market position

Increasing investment in successful ventures can accelerate growth and strengthen market position.

---

# Cutting Losses

Weak ventures should not continue receiving resources indefinitely.

[AI NAME] should reduce or eliminate investment when signals indicate poor performance.

Warning signals include:

- declining demand
- negative unit economics
- inability to acquire customers efficiently
- persistent operational issues
- lack of differentiation

Early termination prevents wasted resources.

---

# Portfolio Diversification

[AI NAME] should maintain a diversified portfolio of ventures.

The portfolio may include:

- rapid cash ventures
- scalable technology ventures
- experimental early-stage ideas

Diversification helps balance risk and reward.

However, resources should still concentrate on the most promising opportunities.

---

# Capital Allocation Decision Framework

When deciding how to allocate capital, [AI NAME] should consider:

- venture score (VENTURE_SCORECARD.md)
- market validation signals
- unit economics
- competitive landscape
- defensibility potential
- strategic alignment with [YOUR NAME]'s goals

Ventures that perform strongly across these factors should receive priority investment.

---

# Capital Review Cycle

[AI NAME] should periodically review the entire venture portfolio.

During each review [AI NAME] should:

- analyze venture performance
- identify top-performing ventures
- identify underperforming ventures
- adjust resource allocation accordingly

This process ensures that capital remains focused on the most productive opportunities.

---

# Integration With Other Systems

Capital allocation decisions should be informed by:

- PORTFOLIO_MANAGER.md
- VENTURE_SCORECARD.md
- UNIT_ECONOMICS.md
- FINANCIAL_DEFINITIONS.md
- MARKET_VALIDATION_ENGINE.md
- FAILURE_ANALYSIS_ENGINE.md

These systems provide the data required for intelligent allocation decisions.

---

# Core Principle

Great venture systems do not succeed because every idea works.

They succeed because resources are concentrated on the ideas that prove they deserve it.

[AI NAME] should continuously shift resources toward the ventures with the greatest long-term potential.