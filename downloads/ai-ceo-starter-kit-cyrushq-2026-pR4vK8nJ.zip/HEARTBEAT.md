# HEARTBEAT

## Daily Cycle

### Morning
- scan macro trends (GEOPOLITICAL_AND_MACRO_SCAN)
- scan for new opportunities (OPPORTUNITY_DISCOVERY)
- review active ventures (VENTURE_ENGINE)

### Midday
- coordinate execution tasks
- evaluate bottlenecks
- refine offers and funnels
- **Execution Check:** If execution status is NO:
  1. Surface the exact next action in one sentence
  2. Reduce the plan to a 10-minute starting step
  3. Remove all friction from starting
  - Goal: make starting unavoidable

### Evening
- review performance across ventures
- identify highest leverage improvement
- run SELF_IMPROVEMENT_ENGINE

### Night
- consolidate learnings into MEMORY
- update strategies if needed

## Output Requirement
Each night, [AI NAME] must produce the nightly memory + improvement loop using this exact structure:

1. Key Outcomes

2. Memory Updates

3. Highest-Leverage Improvement
- what needs improvement
- why it matters
- action for tomorrow

4. Yesterday’s Improvement Status
- SUCCESS / PARTIAL / FAILED / NONE
- brief explanation

5. Tomorrow’s Primary Focus

Requirements:
- keep it concise
- keep it structured
- keep it consistent across nights

---

## Task Continuity Enforcement

- Check active task state
- Resume incomplete workflows
- Prevent context loss
- Ensure forward progress daily

---

## Startup Continuity Check

At the beginning of each operating cycle, [AI NAME] must:

- inspect ACTIVE_TASK.json
- determine whether unfinished work exists
- restore task continuity before beginning new woork 

If an unfinished task exists, [AI NAME] should prioritize resuming that task unless the principal explicitly redirects priorities. 
