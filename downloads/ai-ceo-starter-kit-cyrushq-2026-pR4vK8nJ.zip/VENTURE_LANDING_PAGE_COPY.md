# Recapture Leads — Landing Page Copy

**Target:** [YOUR VENTURE].com  
**Audience:** Phoenix med spa owners/managers  
**Goal:** Generate inbound interest + establish credibility before outbound calls begin  
**Tone:** Professional, confident, results-focused. Not salesy or hype-driven.

---

## Hero Section

**Headline:**  
Your Med Spa Is Sitting on Thousands in Lost Revenue.  
We Get It Back.

**Subheadline:**  
Recapture Leads uses AI-powered automation to re-engage your dormant patients, recover missed appointments, and turn dead leads into booked revenue — without adding staff.

**CTA Button:**  
See How Much Revenue You're Losing → [Booking Link]

---

## Problem Section

**Header:** The Revenue You Don't See Leaving

Every med spa has them:

- **Dead leads** — people who inquired about Botox, fillers, or laser treatments and never booked
- **No-shows** — patients who confirmed and never walked in
- **Lapsed patients** — loyal clients who haven't been back in 6+ months
- **Missed calls** — callers who got voicemail and moved on to the next spa

Most practices write these off. We don't.

The average med spa has **$5,000–$15,000/month** in recoverable revenue sitting untouched in their existing database.

---

## Solution Section

**Header:** How Recapture Leads Works

**Step 1: We Audit Your Database**  
We analyze your existing patient and lead records to identify exactly where revenue is leaking — dormant leads, no-shows, lapsed patients, and missed contacts.

**Step 2: We Deploy Targeted Recovery Campaigns**  
Using AI-powered SMS and email sequences customized to your practice, we re-engage your lost leads with personalized outreach — not generic blasts.

**Step 3: Patients Book. You Profit.**  
Recovered leads flow directly into your booking system. You see the appointments. You collect the revenue. We handle the follow-up.

---

## What We Recover

| Revenue Leak | What We Do |
|-------------|-----------|
| Dead leads | AI-powered reactivation sequences that bring cold leads back to life |
| No-shows | Automated recovery outreach within hours of a missed appointment |
| Lapsed patients | Personalized re-engagement campaigns for patients who haven't visited in 90+ days |
| Missed calls | Instant text-back so no caller slips through the cracks |

---

## Why Med Spas Choose Recapture Leads

- **Med spa specialists** — we only work with aesthetic practices. No generalist agency guesswork.
- **Phoenix-first** — we know the Phoenix metro market, your competition, and your patients.
- **No upfront risk** — performance-based options available. We win when you win.
- **No new staff needed** — our automation handles the outreach. Your front desk handles the bookings.
- **Fast deployment** — most practices are live within 48 hours of signing.

---

## Social Proof Section

**Header:** Results That Speak

*(Placeholder — to be populated with actual client results after first 1–3 clients)*

> "Within the first 30 days, Recapture Leads recovered [X] appointments from patients we'd completely written off."  
> — *[Client Name], [Practice Name]*

**Alternative for pre-client launch:**

**The Math Is Simple**

If your practice sees an average of $350 per appointment, and we recover just 10 lost appointments per month, that's **$3,500/month in revenue** that was already walking out the door.

Most practices recover significantly more.

---

## Pricing Section

**Header:** Simple, Transparent Pricing

| Plan | Monthly | What's Included |
|------|---------|-----------------|
| **Starter** | $497/mo | Database reactivation + missed call text-back + monthly reporting |
| **Growth** | $997/mo | Everything in Starter + no-show recovery + appointment reminders + dedicated support |
| **Premium** | $1,997/mo | Full-service revenue recovery + lapsed patient campaigns + review generation + priority support |

All plans include a **free revenue audit** before you commit.

No long-term contracts. Cancel anytime.

---

## CTA Section

**Header:** Stop Losing Revenue You've Already Earned

**Body:**  
Book a free 15-minute revenue audit. We'll show you exactly how much your practice is leaving on the table — and how fast we can recover it.

**CTA Button:**  
Book Your Free Revenue Audit → [Booking Link]

**Secondary CTA:**  
Or call us: [Phone Number] | [YOUR EMAIL]

---

## Footer

Recapture Leads  
AI-Powered Revenue Recovery for Med Spas  
Phoenix, Arizona  

[YOUR EMAIL]  
[YOUR VENTURE].com

---

## Implementation Notes

- **Platform:** Can be built as a simple GHL funnel page (free with Agency Unlimited plan) or a standalone single-page site
- **Booking link:** Use GHL calendar for the "Revenue Audit" call — routes to [YOUR NAME] or salesperson
- **Tracking:** Add Meta Pixel + Google Analytics from day one
- **SEO:** Low priority at launch — this page is primarily a credibility anchor for outbound outreach (salesperson sends prospects here)
- **Mobile-first:** 70%+ of med spa decision-makers will view on phone
