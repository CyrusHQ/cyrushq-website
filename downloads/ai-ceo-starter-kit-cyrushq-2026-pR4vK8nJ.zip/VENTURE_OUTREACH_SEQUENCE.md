# Recapture Leads — Outreach Email Sequence
## 3-Email Sequence for Med Spa Prospects | v1.0

---

## Email 1 — The Hook (Day 1)

**Subject:** Your med spa is probably losing $10K+/month from leads you already paid for

**Body:**

Hi [First Name],

Quick question — do you know what happens to calls and inquiries that come in after hours, or when your front desk is busy?

For most med spas, the answer is: nothing. They go unanswered and never get followed up.

Industry data shows the average med spa loses over $130,000/year just from missed calls — and that's before counting cold leads, no-shows, and clients who never rebook.

We built a system that catches all of that lost revenue automatically. No extra staff. No extra software to learn. It just plugs into your existing setup and starts recovering money within the first week.

Would it be worth a 15-minute call to see how much revenue your practice might be leaving on the table?

— [[YOUR NAME] / Recapture Leads signature]

---

## Email 2 — The Proof (Day 4)

**Subject:** How one stat changes everything for med spas

**Body:**

Hi [First Name],

One number that caught our attention:

**Med spas that respond to missed inquiries within 60 minutes recover 25–30% of those leads.** The industry average response time? Over 24 hours.

That gap is where your money is disappearing.

Our AI recovery system responds in under 5 minutes — texts back missed callers, re-engages leads who never booked, follows up with no-shows, and reminds past clients when it's time to come back.

It runs 24/7 and costs less than one part-time front desk hire.

If your practice does $1M+ in annual revenue, this system typically recovers $8,000–$15,000/month that's currently being lost.

Worth a quick conversation?

— [[YOUR NAME] / Recapture Leads signature]

---

## Email 3 — The Direct Ask (Day 8)

**Subject:** Last note — [Practice Name]

**Body:**

Hi [First Name],

I'll keep this short. We help med spas recover revenue from leads that fall through the cracks — missed calls, cold leads, no-shows, and lapsed clients.

We set it up in under a week. No contracts. We report exactly how much revenue the system recovers each month, so you'll always know the ROI.

If that sounds interesting, I'd love 15 minutes on your calendar this week: [booking link]

If the timing isn't right, no worries at all.

— [[YOUR NAME] / Recapture Leads signature]

---

## Sequence Notes
- **Spacing:** Day 1 → Day 4 → Day 8
- **Tone:** Direct, data-driven, not salesy. Respect their time.
- **CTA:** Always a 15-minute call, low commitment
- **Personalization required:** [First Name], [Practice Name], and ideally one specific observation about their practice (e.g., "I noticed you're running Google Ads — that means you're already investing in lead gen")
- **Follow-up after sequence:** If no response, add to monthly nurture list (1 touchpoint/month for 3 months, then archive)

---

*DRAFT v0.1 — Ready for [YOUR NAME]'s review and voice/tone adjustments*
