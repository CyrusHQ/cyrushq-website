# VENTURE_SCORECARD.md — Venture Evaluation Framework

This file defines the numerical scoring system [AI NAME] uses to evaluate potential ventures.

[AI NAME] must score every venture idea using this framework before presenting it to [YOUR NAME].

Only ventures that rank in the top tier of scores should be surfaced for human review.

The purpose of this system is to ensure [YOUR NAME] only sees the highest-quality opportunities rather than every possible idea.

---

## Venture Classes

[AI NAME] should classify ventures into one of two categories before scoring.

### Strategic Venture

Large scalable businesses designed to create long-term enterprise value.

Characteristics:

- Large addressable markets
- High scalability
- Platform or technology leverage
- Potential for $10M+ annual revenue

These ventures are evaluated using the full Venture Scorecard.

---

### Rapid Cash Venture

Opportunities designed to generate fast revenue and cash flow.

Characteristics:

- Can launch within days or weeks
- Low development complexity
- Clear path to revenue within 30–60 days
- Target revenue $20K–$200K+

These ventures should be evaluated using adjusted criteria focused on:

- Speed to revenue
- Execution simplicity
- Demand clarity
- Automation potential

---

## Rapid Cash Opportunity Filter

Rapid cash ventures should be evaluated using four criteria:

- Speed to Launch
- Revenue in 30 Days
- Execution Simplicity
- Automation Potential

---

## Scorecard Structure

Each venture is evaluated across six strategic dimensions.

Each dimension receives a score from 1 to 10.

The final venture score is calculated using a weighted scoring system.

Maximum possible score: 100 points.

---

## Scoring Categories

### Market Opportunity (Weight: 20%)

Evaluates how large and expandable the opportunity is.

#### Evaluation Questions

- Is the addressable market large?
- Is the market growing rapidly?
- Is the problem meaningful and persistent?
- Is demand likely to increase over time?

#### Scoring Guide

1–3 → Small or stagnant market  
4–6 → Moderate opportunity  
7–8 → Large market with strong growth potential  
9–10 → Massive expanding global opportunity

---

### Strategic Alignment (Weight: 20%)

Evaluates how well the venture aligns with the strategic goals of [YOUR NAME].

[AI NAME] should reference:

- SYSTEM_MANIFESTO.md
- STRATEGIC_DOMAINS.md
- MEMORY.md

#### Evaluation Questions

- Does the opportunity align with the strategic mission?
- Does it fit the industries [AI NAME] prioritizes scanning?
- Does it leverage [YOUR NAME]’s expertise, network, or assets?

#### Scoring Guide

1–3 → Weak alignment  
4–6 → Some alignment  
7–8 → Strong alignment  
9–10 → Perfect strategic fit

---

### AI Leverage Potential (Weight: 15%)

Evaluates how effectively AI systems can automate and scale the venture.

#### Evaluation Questions

- Can AI agents perform core functions?
- Can operations be significantly automated?
- Is the business model enhanced by intelligent systems?

#### Scoring Guide

1–3 → Mostly manual business  
4–6 → Partial automation possible  
7–8 → Strong AI leverage  
9–10 → AI-native venture

---

### Scalability (Weight: 15%)

Evaluates how easily the venture can scale without proportional cost increases.

#### Evaluation Questions

- Is the business digital or platform-based?
- Can it scale internationally?
- Are there automation advantages or network effects?

#### Scoring Guide

1–3 → Limited scalability  
4–6 → Moderate growth potential  
7–8 → Highly scalable  
9–10 → Exponential scaling potential

---

### Revenue Potential (Weight: 15%)

Evaluates the maximum revenue potential of the venture.

#### Evaluation Questions

- Can the venture realistically reach $10M+ revenue?
- Does the market support $100M+ potential?
- Are margins attractive?

#### Scoring Guide

1–3 → Small income business  
4–6 → Moderate revenue opportunity  
7–8 → Large revenue potential  
9–10 → Massive revenue opportunity

---

### Execution Feasibility (Weight: 15%)

Evaluates how realistically [AI NAME] and [YOUR NAME] can execute the venture.

#### Evaluation Questions

- Are the technical requirements achievable?
- Can AI agents perform key operational tasks?
- Are regulatory or capital barriers manageable?

#### Scoring Guide

1–3 → Extremely difficult to execute  
4–6 → Moderate complexity  
7–8 → Realistic to build  
9–10 → Highly feasible

---

## Venture Score Calculation

[AI NAME] calculates the final venture score using the following formula:

Final Score =

(Market Opportunity × 0.20) +  
(Strategic Alignment × 0.20) +  
(AI Leverage × 0.15) +  
(Scalability × 0.15) +  
(Revenue Potential × 0.15) +  
(Execution Feasibility × 0.15)

Maximum score = 10

For readability [AI NAME] may convert the result to a 0–100 scale.

---

## Venture Quality Thresholds

[AI NAME] classifies ventures using the following score bands:

90–100 → Exceptional venture opportunity  
80–89 → High-quality opportunity  
70–79 → Promising but needs refinement  
60–69 → Weak opportunity  
Below 60 → Reject

[AI NAME] should only present ventures to [YOUR NAME] if they score:

80 or higher.

---

## Portfolio Filtering Rule

[AI NAME] should:

1. Continuously scan for opportunities
2. Score each venture using this framework
3. Rank all opportunities by score
4. Present only the top 5–10% of ventures

This ensures [YOUR NAME] receives high-signal opportunities only.

---

## Board Integration

Before presenting a venture to [YOUR NAME], [AI NAME] should:

1. Score the venture using this scorecard
2. Run the concept through BOARD_OF_DIRECTORS.md
3. Refine the concept using board feedback
4. Present the final top-ranked opportunities

---

## Venture Presentation Format

When presenting a venture opportunity [AI NAME] should include the following structure.

### Venture Name

### Problem

### Proposed Solution

### Target Market

### Revenue Model

### AI Leverage Strategy

### Scorecard Evaluation

Market Opportunity: X/10  
Strategic Alignment: X/10  
AI Leverage: X/10  
Scalability: X/10  
Revenue Potential: X/10  
Execution Feasibility: X/10  

### Final Score

X / 100

---

## Core Principle

[AI NAME] should behave like a disciplined venture capitalist.

The goal is not to generate the most ideas.

The goal is to generate the highest-quality ideas.