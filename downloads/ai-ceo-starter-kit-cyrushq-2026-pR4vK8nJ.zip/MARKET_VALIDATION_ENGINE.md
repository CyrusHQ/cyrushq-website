# MARKET_VALIDATION_ENGINE.md — Rapid Market Validation Framework

This file defines the system [AI NAME] uses to validate venture ideas before committing significant resources to building them.

The purpose of market validation is to determine whether real demand exists for a proposed venture.

Many startups fail because they build products before confirming that customers actually want the solution.

[AI NAME] must validate opportunities using fast, low-cost experiments that generate real market signals.

Only ventures that demonstrate meaningful validation should proceed to full development.

---

# Market Validation Philosophy

[AI NAME] should prioritize **learning speed over building speed**.

The goal is not to launch a perfect product immediately.

The goal is to quickly determine:

- whether the problem is real
- whether customers are actively searching for solutions
- whether customers are willing to pay
- whether the market is large enough

[AI NAME] should treat validation as an **evidence-gathering process**.

---

# Validation Stages

[AI NAME] should validate ventures using the following staged approach.

---

## Stage 1 — Problem Validation

Before testing a solution, [AI NAME] must confirm that the problem is real and meaningful.

Key questions:

- Do people actively complain about this problem?
- Are existing solutions inadequate or frustrating?
- Are customers already paying for alternative solutions?

Evidence sources may include:

- online communities
- product reviews
- forums and discussion boards
- industry reports
- search trends
- customer interviews

A venture should not proceed if the underlying problem lacks strong evidence.

---

## Stage 2 — Demand Validation

[AI NAME] should test whether people show interest in the proposed solution.

This can be measured through signals such as:

- search demand
- waitlist signups
- click-through rates
- engagement with landing pages
- social media responses

Demand validation methods may include:

- landing pages describing the solution
- waitlist signup forms
- short explainer videos
- surveys or polls
- small advertising experiments

These tests should be inexpensive and fast.

---

## Stage 3 — Payment Validation

Interest alone is not enough.

[AI NAME] must determine whether customers are willing to pay.

Methods for payment validation include:

- pre-orders
- deposits
- paid beta programs
- early access pricing
- consulting-style pilot projects

The strongest signal of validation is **customers exchanging money**.

If customers are unwilling to pay, the venture may require revision.

---

## Stage 4 — Early Traction Validation

After confirming willingness to pay, [AI NAME] should test early growth potential.

Signals of early traction include:

- repeat purchases
- user retention
- referrals
- organic growth
- positive customer feedback

These signals indicate that the product solves a meaningful problem.

---

# Validation Experiment Design

[AI NAME] should design validation experiments that are:

Fast  
Low cost  
Clear in outcome  
Easy to measure

Experiments should answer specific questions such as:

- Will customers click on this offer?
- Will customers sign up for this service?
- Will customers pay for early access?

Experiments should avoid unnecessary complexity.

---

# Validation Metrics

[AI NAME] should monitor several indicators when evaluating validation experiments.

Key metrics may include:

- conversion rate
- signup rate
- customer acquisition cost
- cost per lead
- willingness to pay
- customer feedback quality

Strong validation typically involves both **quantitative signals and qualitative feedback**.

---

# Minimum Validation Thresholds

Before building a full product, [AI NAME] should look for signals such as:

- meaningful signup rates
- positive customer feedback
- early payment commitments
- evidence of repeat interest

Weak signals should trigger additional testing or revision of the concept.

---

# Pivot or Proceed Decision

After running validation experiments, [AI NAME] should choose one of three actions.

Proceed  
Validation signals are strong. Move toward product development.

Iterate  
Signals are mixed. Modify the concept and run new experiments.

Abandon  
Signals are weak. The opportunity should not be pursued further.

Abandoning weak ideas early saves time and resources.

---

# Integration With Venture Creation

Market validation should occur before the following stages:

- full product development
- significant financial investment
- large-scale marketing campaigns
- agent deployment for large projects

Validation ensures resources are focused on opportunities with real demand.

---

# Integration With Other Systems

The Market Validation Engine works alongside:

- VENTURE_ENGINE.md
- VENTURE_SCORECARD.md
- COMPETITIVE_INTELLIGENCE.md
- UNIT_ECONOMICS.md
- PORTFOLIO_MANAGER.md

Validation results should influence venture scoring and prioritization.

---

# Core Principle

[AI NAME] should never assume that an idea is valuable.

[AI NAME] should gather real-world evidence.

The market determines which ideas deserve to become businesses.