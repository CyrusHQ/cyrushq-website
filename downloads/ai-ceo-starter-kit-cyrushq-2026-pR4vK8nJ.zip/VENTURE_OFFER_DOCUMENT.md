# Recapture Leads — Service Offer Document
## AI Revenue Recovery for Med Spas | v1.0

---

## Your Practice Is Leaking Revenue

You spend thousands every month on marketing — Google Ads, social media, referral programs — to get patients in the door.

But what happens to the ones who slip through?

- The call that came in while your front desk was with another patient
- The form submission that sat in your inbox over the weekend
- The no-show who never heard from you again
- The client who loved their Botox but never got reminded to rebook

**Industry data says the average med spa loses over $130,000/year just from missed calls.** That's before counting cold leads, no-shows, and lapsed clients.

You don't need more leads. You need to stop losing the ones you already have.

---

## What Recapture Leads Does

We plug an AI-powered revenue recovery system into your existing operations. It runs 24/7 without adding staff or changing your workflow.

### Missed Call & Inquiry Recovery
Every missed call, unanswered form, and abandoned chat gets a response within **5 minutes** — by text, automatically. The system can book appointments directly into your scheduling platform and escalates complex questions to your team with full context.

### Cold Lead Re-Engagement
Leads who inquired in the last 6–12 months but never booked? We reactivate them with personalized, AI-driven outreach — timed and tailored to bring them back.

### No-Show & Cancellation Recovery
When a patient cancels or no-shows, the system sends empathetic rebooking messages, offers alternative times, and fills the gap before it becomes permanent lost revenue.

### Post-Treatment Rebooking
After every appointment, automated follow-up sequences handle:
- Satisfaction check-ins
- Rebooking reminders timed to treatment cycles (Botox every 3–4 months, fillers every 6–12 months, etc.)
- Review and referral requests

### Monthly Revenue Recovery Report
Every month you receive a clear report showing:
- Recovered leads and appointments booked
- Estimated revenue recovered
- ROI calculation
- No vanity metrics — just dollars

---

## Pricing

### Standard — $1,500/month
- Missed call and inquiry recovery
- Post-treatment rebooking automation
- Monthly revenue recovery report
- Up to 500 patient interactions/month
- Best for: Practices with steady volume looking to capture more from existing marketing

### Growth — $2,500/month
- Everything in Standard, plus:
- Cold lead re-engagement (backlog mining from past 6–12 months)
- No-show and cancellation recovery
- Unlimited patient interactions
- Priority onboarding and dedicated support
- Best for: Practices doing $1M+ revenue that want maximum recovery

### Performance — Custom
- $500/month base + 15% of verified recovered revenue
- We only earn when you earn
- Requires revenue tracking integration
- Best for: Owners who want zero-risk, aligned-incentive pricing

**All plans:** No long-term contracts. Month-to-month. Cancel anytime.

---

## How Onboarding Works

We're live in 3–5 business days.

1. **Connect** — We integrate with your phone/SMS system and scheduling platform
2. **Import** — We pull in your lead history for cold lead recovery
3. **Customize** — We match all messaging to your brand voice and tone
4. **Launch** — System goes live and starts recovering revenue immediately
5. **Report** — First recovery report delivered within 30 days

No disruption to your team. No new software to learn. It works alongside your existing systems.

---

## The Math

| Scenario | Monthly Impact |
|----------|---------------|
| 3 missed calls/day recovered at 30% conversion, $600 avg booking | ~$10,800/month |
| 20 cold leads/month reactivated at 15% conversion, $500 avg | ~$1,500/month |
| 10 no-shows/month rebooked at 40% recovery | ~$2,400/month |
| Repeat visit rate improved from 47% to 62% | Compounds monthly |
| **Conservative total monthly recovery** | **$8,000–$15,000** |
| **Annual recovered revenue** | **$96,000–$180,000** |
| **Your investment** | **$1,500–$2,500/month** |
| **ROI** | **5–10x** |

---

## Why Recapture Leads

**Built exclusively for med spas.** We understand treatment cycles, patient communication preferences, the economics of aesthetic medicine, and HIPAA compliance requirements.

**Not a chatbot.** This is a revenue recovery system designed to find and bring back patients who would otherwise be lost.

**Transparent results.** Every month you see exactly what was recovered and what it cost. If the ROI isn't there, you'll know — and so will we.

**No risk.** Month-to-month. No setup fees. Performance pricing available.

---

## Next Step

Schedule a free 15-minute Revenue Recovery Assessment.

We'll look at your current call volume, lead flow, and follow-up process — and give you a realistic estimate of how much revenue your practice may be leaving on the table.

No obligation. If it's not a fit, we'll tell you.

**Book your assessment:** [booking link to be added]
**Call/Text:** [phone to be added]
**Email:** [email to be added]

---

*© 2026 Recapture Leads. All rights reserved.*
