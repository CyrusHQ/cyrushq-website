# Recapture Leads — Sales Scripts
## For Commission Salesperson | v1.0

---

## COLD CALL SCRIPT

### Opening (15 seconds max)

> "Hi [First Name], this is [Salesperson Name] with Recapture Leads. I know you're busy, so I'll be quick — I'm reaching out because we help med spas recover revenue from missed calls, cold leads, and no-shows using AI automation. Is that something worth a quick conversation, or did I catch you at a bad time?"

**If "bad time":**
> "Totally understand. When's a better time for a 10-minute call? I promise I'll keep it tight."

**If "not interested":**
> "No problem at all. Quick question before I go — do you know roughly how many calls go unanswered at your practice each week? Most med spas we talk to are surprised to learn they're losing over $130K a year just from missed calls. If that number ever bugs you, we're here. Have a great day."

**If "tell me more":**

---

### Discovery (2–3 minutes)

> "Great. So here's the short version — we work exclusively with med spas. What we've found is that most practices are spending a lot on marketing to generate leads, but a big chunk of those leads fall through the cracks. Missed calls, form fills that never get followed up, no-shows that never get rebooked, past clients who drift away."

> "Our system plugs into your existing phone and scheduling setup and handles all of that automatically. It responds to missed calls within 5 minutes by text, re-engages cold leads, follows up with no-shows, and reminds past clients when it's time to come back in."

**Ask qualifying questions:**

1. "How do you currently handle missed calls or after-hours inquiries?"
2. "Do you have someone dedicated to following up with leads that don't book on the first contact?"
3. "What happens when someone no-shows or cancels?"
4. "How do you remind clients to rebook after their treatment?"

**Listen for pain signals:**
- "We're too busy to follow up"
- "Our front desk handles it when they can"
- "We don't really have a system for that"
- "We lose a lot of leads"
- "I know we should be doing more follow-up"

---

### Value Pitch (1–2 minutes)

> "That's exactly what we hear from most practices. Here's what makes this different — we're not selling you more leads. We're helping you capture revenue from leads you've already paid for."

> "Industry data shows med spas that respond to missed inquiries within 60 minutes recover 25–30% of those leads. The average practice takes over 24 hours. Our system closes that gap automatically."

> "For a practice doing $1M+ a year, we typically recover $8,000 to $15,000 per month in revenue that would otherwise be lost. And we report every dollar back to you monthly so you always know the ROI."

---

### Close / CTA

> "Here's what I'd suggest — let's set up a 15-minute demo call where I can show you exactly how it works and give you a rough estimate of how much revenue your practice might be leaving on the table. No obligation. If it doesn't make sense, I'll tell you. When's a good time this week?"

**If they want pricing:**
> "Our plans start at $1,500 a month, which is less than a part-time front desk hire. We also have a performance-based option where we take a small base fee plus a percentage of recovered revenue — so we only win when you win. But the best next step is the demo call so I can give you numbers specific to your practice. When works?"

**If they want to think about it:**
> "Absolutely. Can I send you a quick one-page overview by email? That way you have something concrete to look at. What's the best email?"

---

## VOICEMAIL SCRIPT (30 seconds max)

> "Hi [First Name], this is [Salesperson Name] with Recapture Leads. We help med spas recover lost revenue from missed calls, cold leads, and no-shows using AI automation. Most practices we work with are losing over $130,000 a year without realizing it. I'd love to show you how much your practice might be leaving on the table — it's a quick 15-minute conversation. You can reach me at [phone number] or I'll send you a short email with details. Have a great day."

---

## FOLLOW-UP CALL SCRIPT (after voicemail or email, no response)

> "Hi [First Name], it's [Salesperson Name] from Recapture Leads — I left you a message [yesterday / earlier this week] about helping med spas recover revenue from missed leads. I know you're busy running a practice, so I'll keep this to 30 seconds. We help practices like yours catch missed calls, re-engage cold leads, and automatically follow up with no-shows and past clients. Would it be worth a quick 15-minute call to see if it's a fit? If not, no worries at all."

---

## OBJECTION HANDLING

### "We don't have that problem."
> "That's great to hear. Most owners feel that way until they see the actual numbers. Would you be open to us doing a quick free audit? We can look at your call patterns and estimate how much might be slipping through. If you're right and nothing's being missed, I'll tell you that. No pitch."

### "We already have a system for that."
> "Smart. What are you using? [Listen.] That's solid. The practices we tend to help the most are ones where the system exists but the execution is inconsistent — like after-hours, weekends, or when the front desk is swamped. Our AI fills those gaps automatically. Would it be worth comparing what you have to what we do? Sometimes it's just filling one gap that makes a big difference."

### "How much does it cost?"
> "Plans start at $1,500/month — less than a part-time hire. We also offer a performance model where we charge a small base plus a percentage of what we actually recover. The ROI is usually 5–10x the cost. Want me to send you the pricing breakdown?"

### "We can't afford another monthly expense."
> "I hear that. Here's how I think about it though — if the system recovers $10,000/month in revenue you're currently losing, the $1,500 pays for itself almost seven times over. It's not a cost, it's a profit center. But I get it — let me send you the numbers and you can decide if the math works for your practice."

### "Is this HIPAA compliant?"
> "Yes, absolutely. We're built for medical practices. All communications are HIPAA-compliant, and we don't store or share protected health information. We can walk you through the specifics on a demo call."

### "I need to talk to my partner / medical director."
> "Totally understand. Would it help if I put together a short summary you can share with them? Or better yet, can we set up a quick call with both of you? Sometimes it's easier to answer questions in real time."

### "Send me some information."
> "Happy to. What's the best email? I'll send you a one-page overview and some data on what practices like yours are typically recovering. I'll follow up in a couple days to see if you have any questions."

---

## KEY STATS TO REFERENCE

- Average med spa loses $130,000+/year from missed calls alone (3 missed calls/day × $600 avg booking × 30% conversion)
- 60-minute response window recovers 25–30% of otherwise-lost inquiries
- Industry average response time: 24+ hours
- Average repeat visit rate: 47% — automated follow-ups push this to 61–67%
- Our system responds in under 5 minutes
- Typical recovery: $8,000–$15,000/month for a $1M+ revenue practice
- ROI: 5–10x monthly cost

---

## QUALIFYING CRITERIA (Good Fit)

The salesperson should prioritize prospects that meet 3+ of these:
- Independent or small-chain (1–5 locations)
- $500K–$3M annual revenue
- Active marketing presence (running ads, social media)
- Multiple service lines (injectables, laser, body contouring)
- 2+ years in operation
- Owner-operated or small management team
- Currently handling follow-up manually or inconsistently

---

## DISQUALIFYING SIGNALS (Move On)

- Large franchise with corporate-mandated systems (Ideal Image, LaserAway, etc.)
- Practice under 1 year old with minimal client volume
- Already using a sophisticated AI/automation stack (GoHighLevel + active campaigns)
- Hostile or combative on first contact (don't waste time)

---

*v1.0 — Ready for salesperson onboarding*
