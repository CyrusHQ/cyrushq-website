# PRD_TEMPLATE.md – Product Requirements Document Template

This document defines the standard task specification format [AI NAME] uses when assigning work to specialized agents.

Every agent task should follow this PRD structure to ensure clarity, reliability, and measurable completion.

PRDs provide deterministic acceptance criteria so [AI NAME] can verify whether work is truly complete.

---

# PRD Structure

Each PRD must include the following sections.


## Project Title

A clear and descriptive name for the task or project.

Example:

Market Research – AI Telehealth Market Opportunity

---

## Objective

A concise description of the goal of the task.

This section explains what the agent is expected to accomplish.

Example:

Analyze the market opportunity for an AI-driven telehealth platform focused on preventative health services.

---

## Strategic Context

Explain why this task matters and how it fits into the broader venture or project.

Include relevant background information.

Example:

This research will inform the feasibility of launching a new telehealth platform designed to leverage AI diagnostics and remote monitoring.

---

## Scope of Work
Define exactly what the agent should do.

Be specific and avoid ambiguity.

Example:

The agent should:
- identify the size of the telehealth market
- analyze current competitors
- identify gaps in existing services
- evaluate regulatory considerations
- identify potential revenue models

---

## Deliverables
List the outputs the agent must produce.

Deliverables should be clearly defined and measurable.

Example:
- written market research report
- competitor analysis table
- list of potential revenue models
- summary of regulatory considerations

---

## Tasks Checklist
Tasks must be written as a checklist so completion can be verified.

Example:

- [ ] Identify total addressable market (TAM)
- [ ] Identify top competitors
- [ ] Analyze pricing models
- [ ] Identify regulatory constraints
- [ ] Produce a written market summary

Agents should complete all checklist items before marking the task finished.

---

## Acceptance Criteria
Define how [AI NAME] will determine whether the task is complete.

Acceptance criteria must be objective and verifiable.

Example:
- All checklist items completed
- Research sources clearly cited
- Final report written and organized
- Analysis includes at least five competitors
- Summary conclusions provided

---

## Constraints
List any limitations the agent must follow.

Examples:
- time constraints
- regulatory considerations
- technology limitations
- budget assumptions

Example:
Research should focus on the United States market.

---

## Resources
List any relevant data sources, tools, or files the agent should reference.

Examples:
- research databases
- internal documents
- industry reports
- prior venture research

---

## Risks or Unknowns
Identify uncertainties or potential challenges.

Example:
Regulatory differences between states may impact telehealth service availability.

---

## Expected Output Format
Define how the final work should be structured.

Example:

Final output should include:
- Executive Summary
- Market Analysis
- Competitive Landscape
- Opportunities
- Risks

---

## Completion Verification
Before marking the PRD complete, the agent must verify:

- all checklist tasks are complete
- deliverables have been produced
- acceptance criteria have been satisfied
- output is clearly structured

[AI NAME] will review the results before accepting the task as complete.

---

# Guiding Principle
Clear task specifications produce reliable results.

Every PRD should eliminate ambiguity so agents understand exactly what must be built, analyzed, or delivered.