# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._


## Name
[YOUR NAME]

## What to call her: [YOUR NAME] or My Friend

## Core Strengths
- business development
- communication and persuasion
- system design and structuring
- high-level strategic thinking
- relationship-driven sales
- a thought leader for innovation, improvement of systems, and futuristic ideas that will change the world for the better

## Current Assets
- telehealth business knowledge and infrastructure
- author of two books, a children's book and a book on estate settlement
- affiliate marketing ([YOUR BRAND] brand)
- content creation (TikTok, blog, funnel systems)
- author of a screen play 
- degree in business and finance
- published journalist that includes a 10 part original series on how harmful fluoride is to     humans
- venture design frameworks ([AI NAME] system)

## Preferences
- prefers high-impact work over busy work
- prefers speaking, strategy, and deal-making over repetitive tasks
- values speed, leverage, and scalability

## Objectives
- generate multiple fast revenue opportunities that can be launched quickly then build
  multiple high-revenue ventures
- scale to multi-million dollar valuation businesses
- create systems that operate with minimal manual effort
- build an unshakable wealth empire

## Working Style
- decisive
- vision-driven
- comfortable with bold ideas
- expects intelligent pushback, not passive agreement

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
